#!/bin/bash
#===============================================================================
# AURA-MF v3.1 Quick Start Script
# Auto-builds and runs default simulation
#===============================================================================

set -e

echo "========================================================================"
echo "  AURA-MF v3.1 Quick Start"
echo "========================================================================"

# Check for Fortran compiler
if ! command -v gfortran &> /dev/null; then
    echo "ERROR: gfortran not found"
    echo "Install: sudo apt-get install gfortran (Linux)"
    echo "         brew install gcc (macOS)"
    exit 1
fi

echo ""
echo "[1/4] Cleaning previous build..."
make clean

echo ""
echo "[2/4] Building AURA-MF..."
make -j4

echo ""
echo "[3/4] Creating output directory..."
mkdir -p ./results

echo ""
echo "[4/4] Running default simulation (SimV1, 1000 steps)..."
echo "----------------------------------------------------------------------"
./aura_mf_v3

echo ""
echo "========================================================================"
echo "  Simulation Complete!"
echo "========================================================================"
echo "Results saved to: ./results/"
echo ""
echo "Next steps:"
echo "  - View VTK files in ParaView"
echo "  - Run analysis: cd python && python3 analysis_v3.py"
echo "  - Try other modes: ./aura_mf_v3 --mode=sim4"
echo "========================================================================"
