"""
SimV4 Python Wrapper - Reinforcement Learning Orchestrated Multi-Fidelity

This module provides Python integration for SimV4, including:
- Configuration management
- Results parsing and analysis
- RL visualization (Q-values, policy, training curves)
- Fidelity selection timeline plotting
- Comparative performance analysis

Author: AURA-MF Development Team
Date: 2026-02-02
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from dataclasses import dataclass, field, asdict
from typing import List, Dict, Optional, Tuple
from pathlib import Path
import json
import subprocess


@dataclass
class SimV4Config:
    """Configuration for SimV4 RL-orchestrated simulation"""
    
    # Grid and time parameters
    nx: int = 50
    ny: int = 50
    nz: int = 5
    dt: float = 0.1
    t_final: float = 100.0
    n_timesteps: int = 1000
    
    # RL parameters
    n_episodes: int = 100
    learning_rate: float = 0.1
    discount_factor: float = 0.95
    epsilon_start: float = 1.0
    epsilon_end: float = 0.05
    epsilon_decay: float = 0.95
    enable_training: bool = True
    enable_online_learning: bool = False
    
    # State discretization
    n_gradient_bins: int = 5
    n_change_bins: int = 5
    n_budget_bins: int = 5
    max_gradient: float = 100.0
    max_change_rate: float = 50.0
    
    # Reward function weights
    weight_accuracy: float = 1.0
    weight_cost: float = 0.5
    weight_budget: float = 0.2
    weight_switch: float = 0.1
    
    # Computational budget
    initial_budget: float = 100.0
    cost_lf_per_step: float = 0.01
    cost_mf_per_step: float = 0.05
    cost_hf_per_step: float = 1.0
    
    # Physics parameters
    T_target: float = 323.0
    validation_tolerance: float = 2.0
    
    # Output control
    output_directory: str = './results/simv4'
    save_q_table: bool = True
    save_training_history: bool = True
    save_fidelity_timeline: bool = True
    q_table_file: str = 'q_table.dat'
    
    def to_json(self, filename: str):
        """Save configuration to JSON file"""
        with open(filename, 'w') as f:
            json.dump(asdict(self), f, indent=2)
    
    @classmethod
    def from_json(cls, filename: str):
        """Load configuration from JSON file"""
        with open(filename, 'r') as f:
            data = json.load(f)
        return cls(**data)
    
    def validate(self):
        """Validate configuration parameters"""
        assert self.nx > 0, "nx must be positive"
        assert self.learning_rate > 0, "learning_rate must be positive"
        assert 0 <= self.discount_factor <= 1, "discount_factor must be in [0,1]"
        assert 0 <= self.epsilon_start <= 1, "epsilon_start must be in [0,1]"
        assert 0 <= self.epsilon_end <= 1, "epsilon_end must be in [0,1]"
        assert self.n_gradient_bins > 0, "n_gradient_bins must be positive"


@dataclass
class SimV4Results:
    """Results from SimV4 execution including RL metrics"""
    
    # Temperature statistics
    T_avg: float = 0.0
    T_max: float = 0.0
    T_min: float = 0.0
    T_std: float = 0.0
    
    # Fidelity usage
    n_calls_lf: int = 0
    n_calls_mf: int = 0
    n_calls_hf: int = 0
    fidelity_timeline: Optional[List[int]] = None
    
    # RL policy quality
    cumulative_reward: float = 0.0
    avg_reward_per_step: float = 0.0
    avg_q_value: float = 0.0
    policy_entropy: float = 0.0
    final_epsilon: float = 0.0
    
    # Training convergence
    episodes_completed: int = 0
    reward_history: Optional[List[float]] = None
    epsilon_history: Optional[List[float]] = None
    avg_td_error_history: Optional[List[float]] = None
    converged: bool = False
    
    # Performance metrics
    budget_used: float = 0.0
    budget_remaining: float = 0.0
    speedup_vs_pure_hf: float = 0.0
    wall_time_seconds: float = 0.0
    
    # Validation
    rmse_vs_target: float = 0.0
    validation_passed: bool = False
    
    # Comparative performance
    accuracy_vs_simv1: float = 1.0
    cost_vs_simv1: float = 1.0
    efficiency_score: float = 1.0
    
    @classmethod
    def from_csv(cls, filename: str):
        """Load results from CSV summary file"""
        df = pd.read_csv(filename)
        data = dict(zip(df['metric'], df['value']))
        
        # Convert types
        result = cls()
        result.T_avg = float(data.get('T_avg', 0.0))
        result.T_max = float(data.get('T_max', 0.0))
        result.T_min = float(data.get('T_min', 0.0))
        result.T_std = float(data.get('T_std', 0.0))
        
        result.n_calls_lf = int(data.get('n_calls_lf', 0))
        result.n_calls_mf = int(data.get('n_calls_mf', 0))
        result.n_calls_hf = int(data.get('n_calls_hf', 0))
        
        result.cumulative_reward = float(data.get('cumulative_reward', 0.0))
        result.avg_reward_per_step = float(data.get('avg_reward_per_step', 0.0))
        result.avg_q_value = float(data.get('avg_q_value', 0.0))
        
        result.episodes_completed = int(data.get('episodes_completed', 0))
        result.converged = bool(data.get('converged', False))
        
        result.budget_used = float(data.get('budget_used', 0.0))
        result.budget_remaining = float(data.get('budget_remaining', 0.0))
        result.speedup_vs_pure_hf = float(data.get('speedup_vs_pure_hf', 0.0))
        result.wall_time_seconds = float(data.get('wall_time_seconds', 0.0))
        
        result.rmse_vs_target = float(data.get('rmse_vs_target', 0.0))
        result.validation_passed = bool(data.get('validation_passed', False))
        
        result.efficiency_score = float(data.get('efficiency_score', 1.0))
        
        return result
    
    def load_training_history(self, filename: str):
        """Load training history from CSV"""
        df = pd.read_csv(filename)
        self.reward_history = df['reward'].tolist()
        self.epsilon_history = df['epsilon'].tolist()
        self.avg_td_error_history = df['td_error'].tolist()
    
    def load_fidelity_timeline(self, filename: str):
        """Load fidelity timeline from CSV"""
        df = pd.read_csv(filename)
        # Map fidelity names to integers
        fidelity_map = {'[LF]': 0, '[MF]': 1, '[HF]': 2}
        self.fidelity_timeline = [fidelity_map.get(f, 1) for f in df['fidelity']]
    
    def summary(self) -> str:
        """Generate human-readable summary"""
        lines = [
            "=" * 60,
            "SimV4 Results Summary",
            "=" * 60,
            "",
            "RL Policy Performance:",
            f"  Cumulative reward: {self.cumulative_reward:.4f}",
            f"  Avg reward/step: {self.avg_reward_per_step:.6f}",
            f"  Avg Q-value: {self.avg_q_value:.6f}",
            f"  Episodes trained: {self.episodes_completed}",
            f"  Converged: {self.converged}",
            "",
            "Fidelity Usage:",
            f"  LF calls: {self.n_calls_lf} ({self.fidelity_percentage('lf'):.1f}%)",
            f"  MF calls: {self.n_calls_mf} ({self.fidelity_percentage('mf'):.1f}%)",
            f"  HF calls: {self.n_calls_hf} ({self.fidelity_percentage('hf'):.1f}%)",
            "",
            "Temperature:",
            f"  Average: {self.T_avg:.2f} K",
            f"  Range: [{self.T_min:.2f}, {self.T_max:.2f}] K",
            f"  Std dev: {self.T_std:.2f} K",
            "",
            "Performance:",
            f"  Speedup vs pure HF: {self.speedup_vs_pure_hf:.2f}x",
            f"  Budget used: {self.budget_used:.2f}s / {self.budget_used + self.budget_remaining:.2f}s",
            f"  Wall time: {self.wall_time_seconds:.2f}s",
            f"  Efficiency score: {self.efficiency_score:.4f}",
            "",
            "Validation:",
            f"  RMSE: {self.rmse_vs_target:.2f} K",
            f"  Passed: {self.validation_passed}",
            "=" * 60,
        ]
        return "\n".join(lines)
    
    def fidelity_percentage(self, fidelity: str) -> float:
        """Calculate percentage of a fidelity type"""
        total = self.n_calls_lf + self.n_calls_mf + self.n_calls_hf
        if total == 0:
            return 0.0
        if fidelity.lower() == 'lf':
            return 100.0 * self.n_calls_lf / total
        elif fidelity.lower() == 'mf':
            return 100.0 * self.n_calls_mf / total
        elif fidelity.lower() == 'hf':
            return 100.0 * self.n_calls_hf / total
        return 0.0


class SimV4Runner:
    """High-level runner for SimV4 simulations"""
    
    def __init__(self, executable_path: str = './aura_mf'):
        self.executable_path = executable_path
    
    def run(self, config: SimV4Config) -> SimV4Results:
        """Execute SimV4 simulation"""
        # Create output directory
        Path(config.output_directory).mkdir(parents=True, exist_ok=True)
        
        # Save configuration
        config_file = Path(config.output_directory) / 'config.json'
        config.to_json(str(config_file))
        
        # Validate configuration
        config.validate()
        
        # In production, would call Fortran executable
        # For now, simulate results
        print("SimV4 execution would happen here")
        print(f"Output directory: {config.output_directory}")
        
        # Load results
        results = self._load_results(config)
        return results
    
    def _load_results(self, config: SimV4Config) -> SimV4Results:
        """Load results from output files"""
        output_dir = Path(config.output_directory)
        
        # Load summary
        summary_file = output_dir / 'simv4_summary.csv'
        if summary_file.exists():
            results = SimV4Results.from_csv(str(summary_file))
        else:
            results = SimV4Results()
        
        # Load training history
        if config.save_training_history:
            history_file = output_dir / 'training_history.csv'
            if history_file.exists():
                results.load_training_history(str(history_file))
        
        # Load fidelity timeline
        if config.save_fidelity_timeline:
            timeline_file = output_dir / 'fidelity_timeline.csv'
            if timeline_file.exists():
                results.load_fidelity_timeline(str(timeline_file))
        
        return results


# ============================================================================
# VISUALIZATION FUNCTIONS
# ============================================================================

def plot_training_curves(results: SimV4Results, output_file: Optional[str] = None):
    """Plot RL training curves (reward, epsilon, TD error)"""
    if results.reward_history is None:
        print("No training history available")
        return
    
    fig, axes = plt.subplots(3, 1, figsize=(10, 10))
    episodes = np.arange(1, len(results.reward_history) + 1)
    
    # Reward
    axes[0].plot(episodes, results.reward_history, 'b-', linewidth=2)
    axes[0].axhline(np.mean(results.reward_history[-10:]), color='r', 
                   linestyle='--', label='Final avg')
    axes[0].set_xlabel('Episode')
    axes[0].set_ylabel('Cumulative Reward')
    axes[0].set_title('RL Training: Cumulative Reward per Episode')
    axes[0].legend()
    axes[0].grid(True, alpha=0.3)
    
    # Epsilon
    axes[1].plot(episodes, results.epsilon_history, 'g-', linewidth=2)
    axes[1].set_xlabel('Episode')
    axes[1].set_ylabel('Epsilon (ε)')
    axes[1].set_title('Exploration Rate Decay')
    axes[1].grid(True, alpha=0.3)
    
    # TD error
    axes[2].plot(episodes, results.avg_td_error_history, 'r-', linewidth=2)
    axes[2].set_xlabel('Episode')
    axes[2].set_ylabel('Avg TD Error')
    axes[2].set_title('Temporal Difference Error')
    axes[2].grid(True, alpha=0.3)
    
    plt.tight_layout()
    
    if output_file:
        plt.savefig(output_file, dpi=300, bbox_inches='tight')
    plt.show()


def plot_fidelity_timeline(results: SimV4Results, output_file: Optional[str] = None):
    """Plot fidelity selection over time"""
    if results.fidelity_timeline is None:
        print("No fidelity timeline available")
        return
    
    fig, axes = plt.subplots(2, 1, figsize=(12, 8))
    timesteps = np.arange(len(results.fidelity_timeline))
    
    # Timeline
    fidelity_colors = {0: 'green', 1: 'orange', 2: 'red'}
    fidelity_names = {0: 'LF', 1: 'MF', 2: 'HF'}
    colors = [fidelity_colors[f] for f in results.fidelity_timeline]
    
    axes[0].scatter(timesteps, results.fidelity_timeline, c=colors, s=10, alpha=0.6)
    axes[0].set_xlabel('Timestep')
    axes[0].set_ylabel('Fidelity')
    axes[0].set_yticks([0, 1, 2])
    axes[0].set_yticklabels(['LF', 'MF', 'HF'])
    axes[0].set_title('Fidelity Selection Timeline')
    axes[0].grid(True, alpha=0.3)
    
    # Distribution
    unique, counts = np.unique(results.fidelity_timeline, return_counts=True)
    axes[1].bar([fidelity_names[u] for u in unique], counts, 
               color=[fidelity_colors[u] for u in unique], alpha=0.7)
    axes[1].set_xlabel('Fidelity Level')
    axes[1].set_ylabel('Number of Calls')
    axes[1].set_title('Fidelity Distribution')
    axes[1].grid(True, alpha=0.3, axis='y')
    
    # Add percentages
    total = sum(counts)
    for i, (u, c) in enumerate(zip(unique, counts)):
        axes[1].text(i, c, f'{100*c/total:.1f}%', ha='center', va='bottom')
    
    plt.tight_layout()
    
    if output_file:
        plt.savefig(output_file, dpi=300, bbox_inches='tight')
    plt.show()


def plot_policy_heatmap(q_table_file: str, output_file: Optional[str] = None):
    """Plot Q-value heatmap (simplified 2D projection)"""
    # Load Q-table
    q_data = np.loadtxt(q_table_file, skiprows=2)
    
    if len(q_data.shape) == 1:
        q_data = q_data.reshape(-1, 3)  # Assume 3 actions
    
    # Plot heatmap
    fig, ax = plt.subplots(figsize=(10, 8))
    
    im = ax.imshow(q_data, aspect='auto', cmap='RdYlGn')
    ax.set_xlabel('Action (0=LF, 1=MF, 2=HF)')
    ax.set_ylabel('State Index')
    ax.set_title('Q-Table Heatmap')
    
    cbar = plt.colorbar(im, ax=ax)
    cbar.set_label('Q-value')
    
    if output_file:
        plt.savefig(output_file, dpi=300, bbox_inches='tight')
    plt.show()


def plot_comparative_performance(results_dict: Dict[str, SimV4Results], 
                                output_file: Optional[str] = None):
    """Compare multiple SimV4 runs"""
    fig, axes = plt.subplots(2, 2, figsize=(12, 10))
    
    names = list(results_dict.keys())
    
    # Speedup
    speedups = [results_dict[name].speedup_vs_pure_hf for name in names]
    axes[0, 0].bar(names, speedups, alpha=0.7)
    axes[0, 0].set_ylabel('Speedup (×)')
    axes[0, 0].set_title('Speedup vs Pure HF')
    axes[0, 0].grid(True, alpha=0.3, axis='y')
    
    # RMSE
    rmses = [results_dict[name].rmse_vs_target for name in names]
    axes[0, 1].bar(names, rmses, alpha=0.7, color='orange')
    axes[0, 1].set_ylabel('RMSE (K)')
    axes[0, 1].set_title('Accuracy (RMSE vs Target)')
    axes[0, 1].grid(True, alpha=0.3, axis='y')
    
    # Fidelity distribution
    for i, name in enumerate(names):
        r = results_dict[name]
        total = r.n_calls_lf + r.n_calls_mf + r.n_calls_hf
        if total > 0:
            axes[1, 0].bar(i, r.n_calls_lf/total, label='LF' if i == 0 else '', 
                          color='green', alpha=0.7)
            axes[1, 0].bar(i, r.n_calls_mf/total, bottom=r.n_calls_lf/total,
                          label='MF' if i == 0 else '', color='orange', alpha=0.7)
            axes[1, 0].bar(i, r.n_calls_hf/total, 
                          bottom=(r.n_calls_lf + r.n_calls_mf)/total,
                          label='HF' if i == 0 else '', color='red', alpha=0.7)
    axes[1, 0].set_xticks(range(len(names)))
    axes[1, 0].set_xticklabels(names)
    axes[1, 0].set_ylabel('Fraction')
    axes[1, 0].set_title('Fidelity Distribution')
    axes[1, 0].legend()
    
    # Efficiency score
    efficiencies = [results_dict[name].efficiency_score for name in names]
    axes[1, 1].bar(names, efficiencies, alpha=0.7, color='purple')
    axes[1, 1].set_ylabel('Efficiency Score')
    axes[1, 1].set_title('Accuracy / Cost')
    axes[1, 1].grid(True, alpha=0.3, axis='y')
    
    plt.tight_layout()
    
    if output_file:
        plt.savefig(output_file, dpi=300, bbox_inches='tight')
    plt.show()


# ============================================================================
# EXAMPLE USAGE
# ============================================================================

if __name__ == '__main__':
    # Create configuration
    config = SimV4Config(
        nx=50, ny=50, nz=5,
        n_episodes=50,
        learning_rate=0.1,
        discount_factor=0.95,
        enable_training=True,
        output_directory='./results/simv4_example'
    )
    
    # Run simulation
    runner = SimV4Runner()
    results = runner.run(config)
    
    # Print summary
    print(results.summary())
    
    # Visualizations
    # plot_training_curves(results, 'training_curves.png')
    # plot_fidelity_timeline(results, 'fidelity_timeline.png')
