"""
Unit tests for simv1_wrapper.py
Tests high-fidelity simulation wrapper functionality.
"""

import pytest
import subprocess
from pathlib import Path
from unittest.mock import Mock, patch, MagicMock
import sys

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

try:
    from simv1_wrapper import SimV1Wrapper, run_simv1_batch
except ImportError:
    pytest.skip("simv1_wrapper not available", allow_module_level=True)


class TestSimV1Wrapper:
    """Test suite for SimV1 wrapper class."""
    
    def test_wrapper_initialization(self, aura_executable):
        """Test SimV1Wrapper can be initialized."""
        wrapper = SimV1Wrapper(executable=aura_executable)
        assert wrapper is not None
        assert hasattr(wrapper, 'executable')
    
    @pytest.mark.parametrize("timesteps", [10, 50, 100])
    def test_timestep_parameter(self, timesteps, mock_simulation_config):
        """Test different timestep configurations."""
        config = mock_simulation_config.copy()
        config['timesteps'] = timesteps
        assert config['timesteps'] == timesteps
    
    def test_invalid_timesteps(self):
        """Test that invalid timesteps raise appropriate errors."""
        with pytest.raises((ValueError, TypeError)):
            # This should fail - negative timesteps
            config = {'timesteps': -10}
            # Validation logic would catch this
    
    @patch('subprocess.run')
    def test_simulation_execution(self, mock_run, temp_results_dir):
        """Test simulation execution with mocked subprocess."""
        mock_run.return_value = Mock(returncode=0, stdout="Success", stderr="")
        
        # Simulate running wrapper
        result = mock_run(['./aura_mf_v3', '--mode=sim1'])
        assert result.returncode == 0
    
    def test_output_directory_creation(self, temp_results_dir):
        """Test that output directory is created properly."""
        assert temp_results_dir.exists()
        assert temp_results_dir.is_dir()
    
    @pytest.mark.integration
    def test_full_simulation_workflow(self, aura_executable, temp_results_dir):
        """Integration test for complete simulation workflow."""
        # This would run actual simulation if executable exists
        if not Path(aura_executable).exists():
            pytest.skip("Executable not found")
        
        # Run short simulation
        try:
            result = subprocess.run(
                [aura_executable, '--mode=sim1', '--timesteps=5'],
                timeout=60,
                capture_output=True,
                text=True
            )
            # Check it at least runs without crashing
            assert result.returncode in [0, 1]  # Allow some failures in test env
        except subprocess.TimeoutExpired:
            pytest.skip("Simulation timed out")
    
    def test_result_parsing(self, temp_results_dir):
        """Test parsing of simulation results."""
        # Create mock result file
        result_file = temp_results_dir / "output.csv"
        result_file.write_text("time,temperature\n0.0,300.0\n0.1,301.5\n")
        
        assert result_file.exists()
        content = result_file.read_text()
        assert "temperature" in content


class TestBatchSimulation:
    """Test suite for batch simulation functionality."""
    
    def test_batch_configuration(self):
        """Test batch simulation configuration."""
        configs = [
            {'timesteps': 10, 'mode': 'sim1'},
            {'timesteps': 20, 'mode': 'sim1'},
        ]
        assert len(configs) == 2
    
    @patch('subprocess.run')
    def test_batch_execution(self, mock_run):
        """Test batch execution with multiple configurations."""
        mock_run.return_value = Mock(returncode=0, stdout="", stderr="")
        
        configs = [{'id': i} for i in range(3)]
        results = []
        
        for config in configs:
            result = mock_run(['echo', str(config['id'])])
            results.append(result)
        
        assert len(results) == 3
        assert all(r.returncode == 0 for r in results)


class TestErrorHandling:
    """Test error handling in wrapper."""
    
    def test_missing_executable(self):
        """Test handling of missing executable."""
        with pytest.raises((FileNotFoundError, OSError)):
            result = subprocess.run(
                ['/nonexistent/path/aura'],
                capture_output=True
            )
            result.check_returncode()
    
    @patch('subprocess.run')
    def test_simulation_failure_handling(self, mock_run):
        """Test handling of simulation failures."""
        mock_run.return_value = Mock(
            returncode=1,
            stdout="",
            stderr="Error: Simulation failed"
        )
        
        result = mock_run(['./aura_mf_v3'])
        assert result.returncode != 0
        assert "Error" in result.stderr


@pytest.mark.slow
class TestPerformance:
    """Performance-related tests."""
    
    def test_memory_usage(self, mock_grid_data):
        """Test memory usage with large grids."""
        import sys
        
        # Check grid data size
        data_size = sys.getsizeof(mock_grid_data['T'])
        assert data_size > 0
        
        # Ensure it's reasonable size
        max_size = 100 * 1024 * 1024  # 100 MB
        assert data_size < max_size
