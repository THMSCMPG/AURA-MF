"""
Pytest configuration and shared fixtures for AURA-MF test suite.
"""

import os
import tempfile
import shutil
from pathlib import Path
import pytest
import numpy as np


@pytest.fixture(scope="session")
def aura_executable():
    """Path to AURA-MF executable."""
    exe_path = Path(__file__).parent.parent.parent / "aura_mf_v3"
    if not exe_path.exists():
        pytest.skip(f"AURA-MF executable not found: {exe_path}")
    return str(exe_path)


@pytest.fixture(scope="session")
def test_data_dir():
    """Path to test data directory."""
    data_dir = Path(__file__).parent.parent.parent / "data"
    return data_dir


@pytest.fixture
def temp_results_dir():
    """Create temporary directory for test results."""
    temp_dir = tempfile.mkdtemp(prefix="aura_test_")
    yield Path(temp_dir)
    # Cleanup after test
    shutil.rmtree(temp_dir, ignore_errors=True)


@pytest.fixture
def mock_grid_data():
    """Generate mock grid data for testing."""
    nx, ny, nz = 25, 25, 10
    data = {
        'T': np.random.uniform(290, 310, (nx, ny, nz)),
        'phi': np.random.uniform(0, 1, (nx, ny, nz)),
        'nx': nx,
        'ny': ny,
        'nz': nz
    }
    return data


@pytest.fixture
def mock_simulation_config():
    """Mock simulation configuration."""
    config = {
        'mode': 'sim1',
        'timesteps': 10,
        'dt': 0.01,
        'grid_size': [25, 25, 10],
        'output_dir': 'results',
        'fidelity': 'LF'
    }
    return config


@pytest.fixture
def sample_solar_data():
    """Generate sample solar irradiance data."""
    wavelengths = np.linspace(300, 1200, 100)  # nm
    irradiance = np.exp(-(wavelengths - 500)**2 / (2 * 150**2))  # Gaussian
    return wavelengths, irradiance


@pytest.fixture
def sample_temperature_field():
    """Generate sample temperature field."""
    nx, ny = 50, 50
    x = np.linspace(0, 1, nx)
    y = np.linspace(0, 1, ny)
    X, Y = np.meshgrid(x, y)
    
    # Create temperature field with hotspot
    T = 300 + 20 * np.exp(-((X-0.5)**2 + (Y-0.5)**2) / 0.1)
    return T


@pytest.fixture(autouse=True)
def set_random_seed():
    """Set random seed for reproducible tests."""
    np.random.seed(42)


@pytest.fixture
def clean_results_dir():
    """Ensure results directory exists and is clean."""
    results_dir = Path("results")
    if results_dir.exists():
        shutil.rmtree(results_dir)
    results_dir.mkdir()
    yield results_dir
    # Optional: cleanup after test
    # shutil.rmtree(results_dir, ignore_errors=True)


def pytest_configure(config):
    """Configure pytest with custom markers."""
    config.addinivalue_line(
        "markers", "slow: marks tests as slow (deselect with '-m \"not slow\"')"
    )
    config.addinivalue_line(
        "markers", "integration: integration tests"
    )
    config.addinivalue_line(
        "markers", "validation: validation tests against reference data"
    )
