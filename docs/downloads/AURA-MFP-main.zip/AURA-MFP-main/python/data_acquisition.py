#!/usr/bin/env python3
"""
AURA-MF Data Acquisition Script
================================

Downloads and prepares validation datasets for AURA-MF:
- Sandia PVMC experimental data
- Gueymard 2004 atmospheric tables
- ASTM G173-03 solar spectrum data

Author: AURA-MF Development Team
Date: 2026-02-02
"""

import urllib.request
import json
from pathlib import Path
from typing import Dict, List


class DataAcquisitionManager:
    """Manages acquisition of validation and reference datasets"""
    
    def __init__(self, data_dir: str = "data"):
        self.data_dir = Path(data_dir)
        self.validation_dir = self.data_dir / "validation"
        self.atmospheric_dir = self.data_dir / "atmospheric_luts"
        self.material_dir = self.data_dir / "material_properties"
        
        # Ensure directories exist
        self.validation_dir.mkdir(parents=True, exist_ok=True)
        self.atmospheric_dir.mkdir(parents=True, exist_ok=True)
        self.material_dir.mkdir(parents=True, exist_ok=True)
        
    def download_solar_spectrum(self):
        """Download ASTM G173-03 reference solar spectrum"""
        print("📥 Downloading ASTM G173-03 solar spectrum...")
        
        # Note: This is a placeholder URL - actual data should be obtained from NREL
        url = "https://www.nrel.gov/grid/solar-resource/spectra-am1.5.html"
        
        print(f"  ℹ️  Manual download required from: {url}")
        print(f"  ℹ️  Save to: {self.atmospheric_dir / 'astm_g173.csv'}")
        
        # Create a template file
        template_path = self.atmospheric_dir / "astm_g173_template.txt"
        with open(template_path, 'w') as f:
            f.write("# ASTM G173-03 Solar Spectral Irradiance\n")
            f.write("# wavelength(nm), global_tilt(W/m2/nm), direct_normal(W/m2/nm)\n")
            f.write("# Download actual data from NREL website\n")
            
        print(f"  ✅ Template created: {template_path}")
        
    def download_atmospheric_data(self):
        """Download Gueymard atmospheric model data"""
        print("📥 Downloading atmospheric model data...")
        
        print("  ℹ️  Gueymard SMARTS model: http://www.nrel.gov/rredc/smarts/")
        print(f"  ℹ️  Save atmospheric tables to: {self.atmospheric_dir}")
        
        # Create template atmospheric profile
        template = {
            "description": "Standard atmospheric profile",
            "altitude_km": [0, 1, 2, 5, 10, 20, 30, 40, 50],
            "temperature_K": [288.15, 281.65, 275.15, 255.65, 223.25, 216.65, 228.65, 250.35, 270.65],
            "pressure_Pa": [101325, 89875, 79495, 54020, 26436, 5474, 1172, 287, 79],
            "water_vapor_density_g_m3": [7.5, 5.0, 3.0, 1.0, 0.3, 0.001, 0.0001, 0.0, 0.0]
        }
        
        template_path = self.atmospheric_dir / "standard_atmosphere.json"
        with open(template_path, 'w') as f:
            json.dump(template, f, indent=2)
            
        print(f"  ✅ Template created: {template_path}")
        
    def download_sandia_pvmc(self):
        """Download Sandia PVMC experimental validation data"""
        print("📥 Downloading Sandia PVMC validation data...")
        
        print("  ℹ️  Sandia PV Module Database: https://pvpmc.sandia.gov/")
        print(f"  ℹ️  Save experimental data to: {self.validation_dir}")
        
        # Create template validation dataset
        template_path = self.validation_dir / "pvmc_dataset_info.txt"
        with open(template_path, 'w') as f:
            f.write("Sandia PVMC Validation Dataset\n")
            f.write("=" * 50 + "\n\n")
            f.write("Required experimental data:\n")
            f.write("1. Module temperature vs irradiance\n")
            f.write("2. Open-circuit voltage vs temperature\n")
            f.write("3. Short-circuit current vs irradiance\n")
            f.write("4. Power output vs environmental conditions\n\n")
            f.write("Data format: CSV with columns:\n")
            f.write("- timestamp\n")
            f.write("- irradiance (W/m2)\n")
            f.write("- ambient_temp (C)\n")
            f.write("- module_temp (C)\n")
            f.write("- wind_speed (m/s)\n")
            f.write("- power_output (W)\n")
            
        print(f"  ✅ Template created: {template_path}")
        
    def download_silicon_properties(self):
        """Download silicon optical and thermal properties"""
        print("📥 Downloading silicon material properties...")
        
        # Create template optical properties
        optical_template = {
            "description": "Silicon optical properties",
            "wavelength_nm": [300, 400, 500, 600, 700, 800, 900, 1000, 1100, 1200],
            "refractive_index_n": [5.57, 4.53, 4.07, 3.84, 3.71, 3.64, 3.60, 3.58, 3.57, 3.56],
            "extinction_coefficient_k": [3.47, 0.54, 0.05, 0.01, 0.003, 0.001, 0.0005, 0.0002, 0.0001, 0.00005],
            "absorption_coefficient_cm-1": [1e6, 1e5, 1e4, 1e3, 100, 10, 1, 0.1, 0.01, 0.001]
        }
        
        optical_path = self.material_dir / "silicon_optical_template.json"
        with open(optical_path, 'w') as f:
            json.dump(optical_template, f, indent=2)
            
        print(f"  ✅ Template created: {optical_path}")
        
        # Create template thermal properties
        thermal_template = {
            "description": "Silicon thermal properties",
            "temperature_K": [200, 250, 300, 350, 400, 450, 500],
            "thermal_conductivity_W_mK": [264, 191, 148, 120, 99, 84, 73],
            "specific_heat_J_kgK": [640, 700, 712, 730, 760, 800, 850],
            "density_kg_m3": 2329,
            "emissivity": 0.7
        }
        
        thermal_path = self.material_dir / "silicon_thermal_template.json"
        with open(thermal_path, 'w') as f:
            json.dump(thermal_template, f, indent=2)
            
        print(f"  ✅ Template created: {thermal_path}")
        
    def generate_acquisition_report(self):
        """Generate data acquisition status report"""
        report = []
        report.append("\n" + "="*70)
        report.append("DATA ACQUISITION REPORT")
        report.append("="*70)
        report.append("\nData directories created:")
        report.append(f"  - Validation:  {self.validation_dir}")
        report.append(f"  - Atmospheric: {self.atmospheric_dir}")
        report.append(f"  - Materials:   {self.material_dir}")
        report.append("\nTemplates created:")
        report.append(f"  ✅ Solar spectrum template")
        report.append(f"  ✅ Atmospheric profile template")
        report.append(f"  ✅ PVMC validation info")
        report.append(f"  ✅ Silicon optical properties template")
        report.append(f"  ✅ Silicon thermal properties template")
        report.append("\nNext steps:")
        report.append("  1. Download actual ASTM G173-03 data from NREL")
        report.append("  2. Obtain Sandia PVMC experimental datasets")
        report.append("  3. Download SMARTS atmospheric model tables")
        report.append("  4. Populate material property databases")
        report.append("\n" + "="*70 + "\n")
        
        return "\n".join(report)
        
    def run_all(self):
        """Execute all data acquisition tasks"""
        print("\n" + "="*70)
        print("AURA-MF Data Acquisition Manager")
        print("="*70 + "\n")
        
        self.download_solar_spectrum()
        self.download_atmospheric_data()
        self.download_sandia_pvmc()
        self.download_silicon_properties()
        
        print(self.generate_acquisition_report())


if __name__ == "__main__":
    manager = DataAcquisitionManager()
    manager.run_all()
