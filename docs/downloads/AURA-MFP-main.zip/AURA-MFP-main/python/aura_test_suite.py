#!/usr/bin/env python3
"""
AURA-MF Comprehensive Test Suite
=================================

Complete testing framework for the AURA-MF Multi-Fidelity Photovoltaic
Simulation Framework. Includes unit tests, integration tests, validation
tests, and performance benchmarks.

Usage:
    python aura_test_suite.py              # Run all tests
    python aura_test_suite.py --unit       # Run unit tests only
    python aura_test_suite.py --integration # Run integration tests only
    python aura_test_suite.py --validation # Run validation tests only
    python aura_test_suite.py --benchmark  # Run performance benchmarks
    python aura_test_suite.py --quick      # Quick smoke test

Author: AURA-MF Development Team
Date: February 2, 2026
"""

import subprocess
import sys
import os
import json
import time
import argparse
from pathlib import Path
from typing import Dict, List, Tuple, Optional
import csv


class TestResult:
    """Container for test execution results."""
    
    def __init__(self, name: str, passed: bool, duration: float, 
                 message: str = "", output: str = ""):
        self.name = name
        self.passed = passed
        self.duration = duration
        self.message = message
        self.output = output


class AuraTestSuite:
    """Main test suite orchestrator for AURA-MF."""
    
    def __init__(self, aura_executable: str = "./aura_mf", 
                 results_dir: str = "./test_results"):
        """
        Initialize test suite.
        
        Args:
            aura_executable: Path to AURA-MF executable
            results_dir: Directory for test outputs
        """
        self.aura_exe = Path(aura_executable)
        self.results_dir = Path(results_dir)
        self.results_dir.mkdir(exist_ok=True)
        
        self.test_results: List[TestResult] = []
        self.start_time = None
        
    def run_command(self, cmd: List[str], timeout: int = 300) -> Tuple[int, str, str]:
        """
        Execute a command and capture output.
        
        Args:
            cmd: Command to execute as list
            timeout: Maximum execution time in seconds
            
        Returns:
            Tuple of (return_code, stdout, stderr)
        """
        try:
            result = subprocess.run(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=timeout,
                text=True
            )
            return result.returncode, result.stdout, result.stderr
        except subprocess.TimeoutExpired:
            return -1, "", f"Command timed out after {timeout}s"
        except Exception as e:
            return -1, "", str(e)
    
    def check_executable(self) -> bool:
        """Verify AURA-MF executable exists and is runnable."""
        if not self.aura_exe.exists():
            print(f"❌ AURA-MF executable not found: {self.aura_exe}")
            return False
        
        if not os.access(self.aura_exe, os.X_OK):
            print(f"❌ AURA-MF executable not executable: {self.aura_exe}")
            return False
        
        print(f"✅ Found AURA-MF executable: {self.aura_exe}")
        return True
    
    def verify_output_files(self, output_dir: Path, 
                           expected_files: List[str]) -> bool:
        """
        Verify that expected output files were created.
        
        Args:
            output_dir: Directory to check
            expected_files: List of expected filenames
            
        Returns:
            True if all files exist
        """
        missing = []
        for fname in expected_files:
            if not (output_dir / fname).exists():
                missing.append(fname)
        
        if missing:
            print(f"  ⚠️  Missing output files: {missing}")
            return False
        
        return True
    
    def parse_summary_csv(self, csv_path: Path) -> Optional[Dict]:
        """
        Parse simulation summary CSV file.
        
        Args:
            csv_path: Path to summary CSV
            
        Returns:
            Dictionary of parsed values or None
        """
        try:
            with open(csv_path, 'r') as f:
                reader = csv.DictReader(f)
                data = next(reader)  # First row
                return {k: float(v) if k != 'mode' else v 
                       for k, v in data.items()}
        except Exception as e:
            print(f"  ⚠️  Failed to parse {csv_path}: {e}")
            return None
    
    # ========================================================================
    # UNIT TESTS
    # ========================================================================
    
    def test_help_command(self) -> TestResult:
        """Test that --help displays usage information."""
        start = time.time()
        returncode, stdout, stderr = self.run_command([str(self.aura_exe), "--help"])
        duration = time.time() - start
        
        passed = returncode == 0 and "USAGE" in stdout
        message = "Help command successful" if passed else "Help command failed"
        
        return TestResult("help_command", passed, duration, message, stdout)
    
    def test_version_command(self) -> TestResult:
        """Test that --version displays version information."""
        start = time.time()
        returncode, stdout, stderr = self.run_command([str(self.aura_exe), "--version"])
        duration = time.time() - start
        
        passed = returncode == 0 and "AURA-MF" in stdout
        message = "Version command successful" if passed else "Version command failed"
        
        return TestResult("version_command", passed, duration, message, stdout)
    
    def test_invalid_mode(self) -> TestResult:
        """Test that invalid mode is rejected with proper error."""
        start = time.time()
        returncode, stdout, stderr = self.run_command(
            [str(self.aura_exe), "--mode", "invalid_mode"]
        )
        duration = time.time() - start
        
        # Should fail with non-zero return code
        passed = returncode != 0
        message = "Invalid mode properly rejected" if passed else "Invalid mode not rejected"
        
        return TestResult("invalid_mode_rejection", passed, duration, message)
    
    def test_invalid_grid(self) -> TestResult:
        """Test that invalid grid specification is rejected."""
        start = time.time()
        returncode, stdout, stderr = self.run_command(
            [str(self.aura_exe), "--mode", "simv1", "--grid", "invalid"]
        )
        duration = time.time() - start
        
        passed = returncode != 0
        message = "Invalid grid properly rejected" if passed else "Invalid grid not rejected"
        
        return TestResult("invalid_grid_rejection", passed, duration, message)
    
    # ========================================================================
    # INTEGRATION TESTS
    # ========================================================================
    
    def test_simv1_basic(self) -> TestResult:
        """Test SimV1 execution with small grid."""
        test_name = "simv1_basic"
        output_dir = self.results_dir / test_name
        
        start = time.time()
        returncode, stdout, stderr = self.run_command([
            str(self.aura_exe),
            "--mode", "simv1",
            "--grid", "10x10x3",
            "--time", "1.0",
            "--output", str(output_dir)
        ], timeout=60)
        duration = time.time() - start
        
        passed = (returncode == 0 and 
                 self.verify_output_files(output_dir, ["simv1_summary.csv"]))
        
        message = f"SimV1 basic test {'passed' if passed else 'failed'}"
        if passed:
            summary = self.parse_summary_csv(output_dir / "simv1_summary.csv")
            if summary:
                message += f" | T_avg={summary.get('T_avg', 'N/A'):.2f}K"
        
        return TestResult(test_name, passed, duration, message, stdout)
    
    def test_simv2_basic(self) -> TestResult:
        """Test SimV2 execution with multi-fidelity."""
        test_name = "simv2_basic"
        output_dir = self.results_dir / test_name
        
        start = time.time()
        returncode, stdout, stderr = self.run_command([
            str(self.aura_exe),
            "--mode", "simv2",
            "--grid", "10x10x3",
            "--time", "1.0",
            "--output", str(output_dir)
        ], timeout=60)
        duration = time.time() - start
        
        passed = (returncode == 0 and 
                 self.verify_output_files(output_dir, ["simv2_summary.csv"]))
        
        message = f"SimV2 basic test {'passed' if passed else 'failed'}"
        if passed:
            summary = self.parse_summary_csv(output_dir / "simv2_summary.csv")
            if summary:
                speedup = summary.get('speedup_vs_hf', 0)
                message += f" | Speedup={speedup:.1f}x"
        
        return TestResult(test_name, passed, duration, message, stdout)
    
    def test_simv3_basic(self) -> TestResult:
        """Test SimV3 execution with UQ."""
        test_name = "simv3_basic"
        output_dir = self.results_dir / test_name
        
        start = time.time()
        returncode, stdout, stderr = self.run_command([
            str(self.aura_exe),
            "--mode", "simv3",
            "--grid", "10x10x3",
            "--time", "1.0",
            "--output", str(output_dir)
        ], timeout=90)
        duration = time.time() - start
        
        passed = (returncode == 0 and 
                 self.verify_output_files(output_dir, ["simv3_summary.csv"]))
        
        message = f"SimV3 basic test {'passed' if passed else 'failed'}"
        if passed:
            summary = self.parse_summary_csv(output_dir / "simv3_summary.csv")
            if summary:
                speedup = summary.get('speedup_vs_hf', 0)
                message += f" | Speedup={speedup:.1f}x"
        
        return TestResult(test_name, passed, duration, message, stdout)
    
    def test_simv4_basic(self) -> TestResult:
        """Test SimV4 execution with RL orchestration."""
        test_name = "simv4_basic"
        output_dir = self.results_dir / test_name
        
        start = time.time()
        returncode, stdout, stderr = self.run_command([
            str(self.aura_exe),
            "--mode", "simv4",
            "--grid", "10x10x3",
            "--budget", "100",
            "--output", str(output_dir)
        ], timeout=120)
        duration = time.time() - start
        
        expected_files = ["simv4_summary.csv", "q_table.dat", "training_history.csv"]
        passed = (returncode == 0 and 
                 self.verify_output_files(output_dir, expected_files))
        
        message = f"SimV4 basic test {'passed' if passed else 'failed'}"
        if passed:
            summary = self.parse_summary_csv(output_dir / "simv4_summary.csv")
            if summary:
                speedup = summary.get('speedup_vs_hf', 0)
                converged = summary.get('rl_converged', 0)
                message += f" | Speedup={speedup:.1f}x | RL={'✓' if converged else '✗'}"
        
        return TestResult(test_name, passed, duration, message, stdout)
    
    # ========================================================================
    # VALIDATION TESTS
    # ========================================================================
    
    def test_temperature_accuracy(self) -> TestResult:
        """Validate temperature accuracy against known solution."""
        test_name = "temperature_accuracy"
        output_dir = self.results_dir / test_name
        
        # Run SimV1 (ground truth)
        start = time.time()
        returncode, stdout, stderr = self.run_command([
            str(self.aura_exe),
            "--mode", "simv1",
            "--grid", "25x25x5",
            "--time", "10.0",
            "--output", str(output_dir)
        ], timeout=180)
        duration = time.time() - start
        
        if returncode != 0:
            return TestResult(test_name, False, duration, 
                            "SimV1 execution failed", stdout)
        
        summary = self.parse_summary_csv(output_dir / "simv1_summary.csv")
        if not summary:
            return TestResult(test_name, False, duration,
                            "Failed to parse results", stdout)
        
        # Validate temperature is physically reasonable
        T_avg = summary.get('T_avg', 0)
        T_min = summary.get('T_min', 0)
        T_max = summary.get('T_max', 0)
        
        # Expected range: 290K - 400K for PV systems
        passed = (290 < T_avg < 400 and 
                 280 < T_min < T_avg and 
                 T_avg < T_max < 450)
        
        message = (f"Temperature validation {'passed' if passed else 'failed'} | "
                  f"T_avg={T_avg:.2f}K, T_min={T_min:.2f}K, T_max={T_max:.2f}K")
        
        return TestResult(test_name, passed, duration, message, stdout)
    
    def test_fidelity_accuracy(self) -> TestResult:
        """Validate multi-fidelity maintains accuracy."""
        test_name = "fidelity_accuracy"
        
        # Run SimV1 (reference)
        ref_dir = self.results_dir / f"{test_name}_ref"
        start = time.time()
        returncode_ref, _, _ = self.run_command([
            str(self.aura_exe),
            "--mode", "simv1",
            "--grid", "20x20x4",
            "--time", "5.0",
            "--output", str(ref_dir)
        ], timeout=120)
        
        # Run SimV2 (multi-fidelity)
        mf_dir = self.results_dir / f"{test_name}_mf"
        returncode_mf, stdout_mf, _ = self.run_command([
            str(self.aura_exe),
            "--mode", "simv2",
            "--grid", "20x20x4",
            "--time", "5.0",
            "--output", str(mf_dir)
        ], timeout=120)
        duration = time.time() - start
        
        if returncode_ref != 0 or returncode_mf != 0:
            return TestResult(test_name, False, duration,
                            "Execution failed", stdout_mf)
        
        ref_summary = self.parse_summary_csv(ref_dir / "simv1_summary.csv")
        mf_summary = self.parse_summary_csv(mf_dir / "simv2_summary.csv")
        
        if not ref_summary or not mf_summary:
            return TestResult(test_name, False, duration,
                            "Failed to parse results", stdout_mf)
        
        # Calculate relative error
        T_ref = ref_summary['T_avg']
        T_mf = mf_summary['T_avg']
        rel_error = abs(T_ref - T_mf) / T_ref * 100
        
        # Should be within 2% (2K RMSE target ~= 0.6% at 323K)
        passed = rel_error < 2.0
        
        message = (f"Fidelity accuracy {'passed' if passed else 'failed'} | "
                  f"Error={rel_error:.2f}% | "
                  f"T_ref={T_ref:.2f}K, T_mf={T_mf:.2f}K")
        
        return TestResult(test_name, passed, duration, message, stdout_mf)
    
    # ========================================================================
    # PERFORMANCE BENCHMARKS
    # ========================================================================
    
    def benchmark_mode_comparison(self) -> TestResult:
        """Benchmark all modes on same problem."""
        test_name = "mode_comparison_benchmark"
        
        grid_spec = "30x30x5"
        time_spec = "10.0"
        
        results = {}
        start = time.time()
        
        for mode in ["simv1", "simv2", "simv3", "simv4"]:
            output_dir = self.results_dir / f"{test_name}_{mode}"
            
            budget_args = ["--budget", "200"] if mode == "simv4" else ["--time", time_spec]
            time_args = [] if mode == "simv4" else ["--time", time_spec]
            
            mode_start = time.time()
            returncode, stdout, stderr = self.run_command([
                str(self.aura_exe),
                "--mode", mode,
                "--grid", grid_spec,
                *budget_args,
                *time_args,
                "--output", str(output_dir)
            ], timeout=300)
            mode_duration = time.time() - mode_start
            
            if returncode == 0:
                summary = self.parse_summary_csv(output_dir / f"{mode}_summary.csv")
                if summary:
                    results[mode] = {
                        'duration': mode_duration,
                        'T_avg': summary.get('T_avg', 0),
                        'speedup': summary.get('speedup_vs_hf', 1.0)
                    }
        
        duration = time.time() - start
        
        # Check we got all modes
        passed = len(results) == 4
        
        if passed:
            message = "Mode comparison benchmark completed:\n"
            for mode, data in results.items():
                message += (f"  {mode}: {data['duration']:.1f}s, "
                          f"T={data['T_avg']:.2f}K, "
                          f"Speedup={data['speedup']:.1f}x\n")
        else:
            message = f"Mode comparison failed: only {len(results)}/4 modes completed"
        
        return TestResult(test_name, passed, duration, message)
    
    def benchmark_scaling(self) -> TestResult:
        """Benchmark grid size scaling."""
        test_name = "scaling_benchmark"
        
        grids = ["10x10x3", "20x20x4", "40x40x5", "80x80x7"]
        mode = "simv2"
        
        results = []
        start = time.time()
        
        for grid in grids:
            output_dir = self.results_dir / f"{test_name}_{grid.replace('x', '_')}"
            
            grid_start = time.time()
            returncode, stdout, stderr = self.run_command([
                str(self.aura_exe),
                "--mode", mode,
                "--grid", grid,
                "--time", "5.0",
                "--output", str(output_dir)
            ], timeout=300)
            grid_duration = time.time() - grid_start
            
            if returncode == 0:
                # Calculate grid size
                nx, ny, nz = map(int, grid.split('x'))
                grid_points = nx * ny * nz
                
                results.append({
                    'grid': grid,
                    'points': grid_points,
                    'duration': grid_duration,
                    'points_per_sec': grid_points / grid_duration
                })
        
        duration = time.time() - start
        
        passed = len(results) == len(grids)
        
        if passed:
            message = "Scaling benchmark completed:\n"
            for r in results:
                message += (f"  {r['grid']}: {r['duration']:.1f}s, "
                          f"{r['points_per_sec']:.0f} pts/s\n")
        else:
            message = f"Scaling benchmark failed: {len(results)}/{len(grids)} completed"
        
        return TestResult(test_name, passed, duration, message)
    
    # ========================================================================
    # TEST EXECUTION
    # ========================================================================
    
    def run_unit_tests(self):
        """Run all unit tests."""
        print("\n" + "="*70)
        print("UNIT TESTS")
        print("="*70)
        
        tests = [
            self.test_help_command,
            self.test_version_command,
            self.test_invalid_mode,
            self.test_invalid_grid,
        ]
        
        for test_func in tests:
            result = test_func()
            self.test_results.append(result)
            status = "✅ PASS" if result.passed else "❌ FAIL"
            print(f"{status} | {result.name} | {result.duration:.2f}s")
            if result.message:
                print(f"     {result.message}")
    
    def run_integration_tests(self):
        """Run all integration tests."""
        print("\n" + "="*70)
        print("INTEGRATION TESTS")
        print("="*70)
        
        tests = [
            self.test_simv1_basic,
            self.test_simv2_basic,
            self.test_simv3_basic,
            self.test_simv4_basic,
        ]
        
        for test_func in tests:
            result = test_func()
            self.test_results.append(result)
            status = "✅ PASS" if result.passed else "❌ FAIL"
            print(f"{status} | {result.name} | {result.duration:.2f}s")
            if result.message:
                print(f"     {result.message}")
    
    def run_validation_tests(self):
        """Run all validation tests."""
        print("\n" + "="*70)
        print("VALIDATION TESTS")
        print("="*70)
        
        tests = [
            self.test_temperature_accuracy,
            self.test_fidelity_accuracy,
        ]
        
        for test_func in tests:
            result = test_func()
            self.test_results.append(result)
            status = "✅ PASS" if result.passed else "❌ FAIL"
            print(f"{status} | {result.name} | {result.duration:.2f}s")
            if result.message:
                print(f"     {result.message}")
    
    def run_benchmarks(self):
        """Run all performance benchmarks."""
        print("\n" + "="*70)
        print("PERFORMANCE BENCHMARKS")
        print("="*70)
        
        tests = [
            self.benchmark_mode_comparison,
            self.benchmark_scaling,
        ]
        
        for test_func in tests:
            result = test_func()
            self.test_results.append(result)
            status = "✅ DONE" if result.passed else "⚠️  INCOMPLETE"
            print(f"{status} | {result.name} | {result.duration:.2f}s")
            if result.message:
                for line in result.message.split('\n'):
                    if line.strip():
                        print(f"     {line}")
    
    def run_quick_test(self):
        """Run minimal smoke test."""
        print("\n" + "="*70)
        print("QUICK SMOKE TEST")
        print("="*70)
        
        result = self.test_simv1_basic()
        self.test_results.append(result)
        status = "✅ PASS" if result.passed else "❌ FAIL"
        print(f"{status} | {result.name} | {result.duration:.2f}s")
        if result.message:
            print(f"     {result.message}")
    
    def generate_report(self):
        """Generate test report."""
        print("\n" + "="*70)
        print("TEST SUMMARY")
        print("="*70)
        
        total = len(self.test_results)
        passed = sum(1 for r in self.test_results if r.passed)
        failed = total - passed
        total_duration = sum(r.duration for r in self.test_results)
        
        print(f"\nTotal Tests: {total}")
        print(f"Passed: {passed} ✅")
        print(f"Failed: {failed} ❌")
        print(f"Pass Rate: {passed/total*100:.1f}%")
        print(f"Total Duration: {total_duration:.1f}s")
        
        # Save JSON report
        report_file = self.results_dir / "test_report.json"
        report = {
            'timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
            'total_tests': total,
            'passed': passed,
            'failed': failed,
            'pass_rate': passed/total*100,
            'total_duration': total_duration,
            'results': [
                {
                    'name': r.name,
                    'passed': r.passed,
                    'duration': r.duration,
                    'message': r.message
                }
                for r in self.test_results
            ]
        }
        
        with open(report_file, 'w') as f:
            json.dump(report, f, indent=2)
        
        print(f"\nDetailed report saved: {report_file}")
        
        return passed == total


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="AURA-MF Comprehensive Test Suite",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python aura_test_suite.py                # Run all tests
  python aura_test_suite.py --quick        # Quick smoke test
  python aura_test_suite.py --unit         # Unit tests only
  python aura_test_suite.py --integration  # Integration tests only
        """
    )
    
    parser.add_argument('--exe', default='./aura_mf',
                       help='Path to AURA-MF executable')
    parser.add_argument('--output', default='./test_results',
                       help='Output directory for test results')
    parser.add_argument('--unit', action='store_true',
                       help='Run unit tests only')
    parser.add_argument('--integration', action='store_true',
                       help='Run integration tests only')
    parser.add_argument('--validation', action='store_true',
                       help='Run validation tests only')
    parser.add_argument('--benchmark', action='store_true',
                       help='Run performance benchmarks only')
    parser.add_argument('--quick', action='store_true',
                       help='Run quick smoke test only')
    
    args = parser.parse_args()
    
    # Create test suite
    suite = AuraTestSuite(args.exe, args.output)
    
    # Check executable exists
    if not suite.check_executable():
        sys.exit(1)
    
    print("\n" + "="*70)
    print("AURA-MF COMPREHENSIVE TEST SUITE")
    print("="*70)
    print(f"Executable: {suite.aura_exe}")
    print(f"Results Dir: {suite.results_dir}")
    
    suite.start_time = time.time()
    
    # Run requested tests
    if args.quick:
        suite.run_quick_test()
    elif args.unit:
        suite.run_unit_tests()
    elif args.integration:
        suite.run_integration_tests()
    elif args.validation:
        suite.run_validation_tests()
    elif args.benchmark:
        suite.run_benchmarks()
    else:
        # Run all
        suite.run_unit_tests()
        suite.run_integration_tests()
        suite.run_validation_tests()
        suite.run_benchmarks()
    
    # Generate report
    all_passed = suite.generate_report()
    
    # Exit with appropriate code
    sys.exit(0 if all_passed else 1)


if __name__ == "__main__":
    main()
