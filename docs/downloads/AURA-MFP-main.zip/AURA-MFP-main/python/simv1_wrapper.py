"""
SimV1 Python Wrapper
====================

Python interface for AURA-MF SimV1 (High-Fidelity + Adjoint) simulation mode.

This module provides:
- High-level Python API for SimV1 execution
- Configuration management
- Results parsing and visualization
- Integration with ML training pipeline

Author: AURA-MF Development Team
Date: 2026-02-02 (Batch 4)
"""

import subprocess
import json
import numpy as np
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
import matplotlib.pyplot as plt


@dataclass
class SimV1Config:
    """Configuration for SimV1 simulation"""
    # Simulation parameters
    grid_size: Tuple[int, int, int] = (50, 50, 5)
    timestep: float = 0.01  # seconds
    total_time: float = 10.0  # seconds
    
    # Physics parameters
    solar_irradiance: float = 1000.0  # W/m²
    ambient_temperature: float = 293.0  # K (20°C)
    wind_speed: float = 1.0  # m/s
    
    # Analysis options
    enable_adjoint: bool = True
    enable_validation: bool = True
    
    # Output control
    output_directory: str = "results/simv1"
    output_frequency: int = 10  # Output every N steps
    write_vtk: bool = False
    write_csv: bool = True
    
    # Design parameters for sensitivity
    design_params: List[str] = None
    
    def __post_init__(self):
        if self.design_params is None:
            self.design_params = [
                'thermal_conductivity',
                'absorption_coefficient', 
                'convection_coefficient'
            ]
    
    def to_json(self) -> str:
        """Convert configuration to JSON"""
        config_dict = {
            'grid_size': list(self.grid_size),
            'timestep': self.timestep,
            'total_time': self.total_time,
            'solar_irradiance': self.solar_irradiance,
            'ambient_temperature': self.ambient_temperature,
            'wind_speed': self.wind_speed,
            'enable_adjoint': self.enable_adjoint,
            'enable_validation': self.enable_validation,
            'output_directory': self.output_directory,
            'output_frequency': self.output_frequency,
            'write_vtk': self.write_vtk,
            'write_csv': self.write_csv,
            'design_params': self.design_params
        }
        return json.dumps(config_dict, indent=2)


@dataclass
class SimV1Results:
    """Results from SimV1 simulation"""
    # Final state
    T_final_avg: float = 0.0
    T_final_max: float = 0.0
    T_final_min: float = 0.0
    
    # Objective function
    J_objective: float = 0.0
    J_temperature_error: float = 0.0
    
    # Validation
    rmse_vs_experimental: float = 0.0
    validation_passed: bool = False
    
    # Performance
    total_wall_time: float = 0.0
    time_per_timestep: float = 0.0
    total_timesteps: int = 0
    
    # Sensitivities
    sensitivities: Optional[Dict[str, float]] = None
    
    @classmethod
    def from_csv(cls, filepath: str, param_names: List[str] = None):
        """Load results from CSV file"""
        results = cls()
        
        with open(filepath, 'r') as f:
            lines = f.readlines()
            
        # Parse CSV (simple key,value format)
        for line in lines:
            if ',' not in line or line.startswith('SimV1'):
                continue
                
            key, value = line.strip().split(',', 1)
            
            if key == 'T_final_avg':
                results.T_final_avg = float(value)
            elif key == 'T_final_max':
                results.T_final_max = float(value)
            elif key == 'T_final_min':
                results.T_final_min = float(value)
            elif key == 'J_objective':
                results.J_objective = float(value)
            elif key == 'RMSE_vs_experimental':
                results.rmse_vs_experimental = float(value)
            elif key == 'Validation_passed':
                results.validation_passed = (value.strip().lower() == 't')
            elif key == 'Total_wall_time':
                results.total_wall_time = float(value)
            elif key == 'Time_per_timestep':
                results.time_per_timestep = float(value)
            elif key == 'Total_timesteps':
                results.total_timesteps = int(value)
                
        return results
    
    def summary(self) -> str:
        """Generate summary string"""
        lines = []
        lines.append("SimV1 Results Summary")
        lines.append("=" * 50)
        lines.append(f"Final Temperature:     {self.T_final_avg:.2f} K")
        lines.append(f"Temperature Range:     {self.T_final_min:.2f} - {self.T_final_max:.2f} K")
        lines.append(f"Objective Function:    {self.J_objective:.4e}")
        lines.append(f"RMSE vs Target:        {self.rmse_vs_experimental:.4f} K")
        lines.append(f"Validation:            {'PASSED' if self.validation_passed else 'FAILED'}")
        lines.append(f"Wall Time:             {self.total_wall_time:.2f} s")
        lines.append(f"Timesteps:             {self.total_timesteps}")
        
        if self.sensitivities:
            lines.append("")
            lines.append("Sensitivities:")
            for param, value in self.sensitivities.items():
                lines.append(f"  ∂J/∂{param:25s} = {value:12.4e}")
        
        return "\n".join(lines)


class SimV1Runner:
    """High-level interface for running SimV1 simulations"""
    
    def __init__(self, aura_executable: str = "./bin/aura_mf"):
        self.executable = Path(aura_executable)
        
        if not self.executable.exists():
            raise FileNotFoundError(f"AURA-MF executable not found: {self.executable}")
    
    def run(self, config: SimV1Config) -> SimV1Results:
        """
        Run SimV1 simulation
        
        Args:
            config: Simulation configuration
            
        Returns:
            Simulation results
        """
        # Create output directory
        output_dir = Path(config.output_directory)
        output_dir.mkdir(parents=True, exist_ok=True)
        
        # Write configuration file
        config_file = output_dir / "simv1_config.json"
        with open(config_file, 'w') as f:
            f.write(config.to_json())
        
        # Build command
        nx, ny, nz = config.grid_size
        cmd = [
            str(self.executable),
            '--mode', 'simv1',
            '--grid', f'{nx}x{ny}x{nz}',
            '--dt', str(config.timestep),
            '--time', str(config.total_time),
            '--output', str(output_dir)
        ]
        
        # Run simulation
        print(f"Running SimV1: {' '.join(cmd)}")
        result = subprocess.run(cmd, capture_output=True, text=True)
        
        if result.returncode != 0:
            print("STDOUT:", result.stdout)
            print("STDERR:", result.stderr)
            raise RuntimeError(f"SimV1 execution failed with code {result.returncode}")
        
        # Parse results
        results_file = output_dir / "simv1_timeseries.csv"
        
        if results_file.exists():
            results = SimV1Results.from_csv(str(results_file), config.design_params)
        else:
            # Parse from stdout if CSV not available
            results = self._parse_stdout(result.stdout, config)
        
        return results
    
    def _parse_stdout(self, stdout: str, config: SimV1Config) -> SimV1Results:
        """Parse results from stdout if CSV not available"""
        results = SimV1Results()
        
        # Simple parsing - look for key lines
        for line in stdout.split('\n'):
            if 'Final average temperature:' in line:
                try:
                    temp_str = line.split(':')[1].strip().split()[0]
                    results.T_final_avg = float(temp_str)
                except:
                    pass
            elif 'Objective function J =' in line:
                try:
                    obj_str = line.split('=')[1].strip()
                    results.J_objective = float(obj_str)
                except:
                    pass
        
        return results
    
    def run_sensitivity_study(
        self,
        base_config: SimV1Config,
        param_name: str,
        param_values: np.ndarray
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Run sensitivity study by varying a single parameter
        
        Args:
            base_config: Base configuration
            param_name: Parameter to vary
            param_values: Array of parameter values to test
            
        Returns:
            (param_values, objective_values) arrays
        """
        objectives = []
        
        for value in param_values:
            # Create modified config
            config = SimV1Config(**base_config.__dict__)
            
            # Modify parameter (simplified - would need proper mapping)
            if param_name == 'solar_irradiance':
                config.solar_irradiance = value
            elif param_name == 'wind_speed':
                config.wind_speed = value
            elif param_name == 'timestep':
                config.timestep = value
            
            # Run simulation
            results = self.run(config)
            objectives.append(results.J_objective)
        
        return param_values, np.array(objectives)


def plot_sensitivity_study(
    param_values: np.ndarray,
    objectives: np.ndarray,
    param_name: str,
    save_path: Optional[str] = None
):
    """Plot results of sensitivity study"""
    plt.figure(figsize=(10, 6))
    plt.plot(param_values, objectives, 'o-', linewidth=2, markersize=8)
    plt.xlabel(param_name, fontsize=12)
    plt.ylabel('Objective Function J', fontsize=12)
    plt.title(f'Sensitivity to {param_name}', fontsize=14)
    plt.grid(True, alpha=0.3)
    
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"Sensitivity plot saved to {save_path}")
    
    plt.show()


def example_usage():
    """Example usage of SimV1 Python wrapper"""
    
    # Create configuration
    config = SimV1Config(
        grid_size=(50, 50, 5),
        timestep=0.01,
        total_time=10.0,
        solar_irradiance=1000.0,
        ambient_temperature=293.0,
        wind_speed=1.0,
        enable_adjoint=True,
        enable_validation=True
    )
    
    # Create runner
    runner = SimV1Runner()
    
    # Run simulation
    print("Running SimV1 simulation...")
    results = runner.run(config)
    
    # Display results
    print("\n" + results.summary())
    
    # Run sensitivity study
    print("\nRunning sensitivity study...")
    irradiance_values = np.linspace(800, 1200, 5)
    params, objs = runner.run_sensitivity_study(
        config,
        'solar_irradiance',
        irradiance_values
    )
    
    # Plot results
    plot_sensitivity_study(
        params,
        objs,
        'Solar Irradiance (W/m²)',
        'results/simv1/sensitivity_irradiance.png'
    )


if __name__ == "__main__":
    example_usage()
