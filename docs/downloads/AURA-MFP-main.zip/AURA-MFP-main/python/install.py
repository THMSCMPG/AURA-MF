#!/usr/bin/env python3
"""
AURA-MF Installation Wizard
===========================

Interactive installation script for AURA-MF.
"""

import os
import sys
import subprocess
import platform
from pathlib import Path

print("AURA-MF Installation Wizard")
print("=" * 50)

# Check Python version
if sys.version_info < (3, 8):
    print("Error: Python 3.8+ required")
    sys.exit(1)

# Check Fortran compiler
try:
    result = subprocess.run(['gfortran', '--version'], capture_output=True)
    print("✓ gfortran found")
except:
    print("✗ gfortran not found - please install gfortran")
    sys.exit(1)

# Build
print("\nBuilding AURA-MF...")
subprocess.run(['make', 'clean'])
subprocess.run(['make'])

print("\n✓ Installation complete!")
