# AURA-MF Data Acquisition Guide

## Required Data Files

### 1. Sandia PVMC Validation Dataset
**Location**: `data/sandia_validation/`

**How to obtain**:
1. Visit: https://pvpmc.sandia.gov/
2. Navigate to: Data Sets → Module Temperature
3. Download: Module temperature validation dataset
4. Required columns: timestamp, T_module, G_poa, T_ambient, wind_speed

**Alternative**: Use NREL PVDAQ
- https://maps.nrel.gov/pvdaq/
- Select site with module temperature measurements
- Export hourly data for one year

**Format**: CSV with header
**Size**: ~8,760 rows (1 year, hourly)

---

### 2. Atmospheric Spectral Irradiance
**Location**: `data/atmospheric_luts/`

**How to obtain**:
1. **ASTM G173-03 Reference Spectra** (recommended)
   - Download from: https://www.nrel.gov/grid/solar-resource/spectra-am1.5.html
   - Files needed:
     - AM1.5 Global (tilted)
     - AM1.5 Direct + Circumsolar
   
2. **SMARTS Model** (alternative)
   - Software: https://www.nrel.gov/grid/solar-resource/smarts.html
   - Generate custom spectra for your location
   - Parameters: Latitude, elevation, turbidity

3. **Use provided template**
   - The template in `atmospheric_luts/am15_global.csv` has basic AM1.5 data
   - For production, replace with full ASTM G173-03 dataset

**Format**: CSV (wavelength [μm], irradiance [W/m²/μm])
**Size**: 100-2000 wavelength points

---

### 3. Material Optical Properties
**Location**: `data/material_properties/`

**Silicon optical properties**:
- **Source**: Green, M. A., & Keevers, M. J. (1995)
  "Optical properties of intrinsic silicon at 300 K"
  Progress in Photovoltaics, 3(3), 189-192
  
- **Download**: https://www.pvlighthouse.com.au/refractive-index
  - Select: Silicon (crystalline)
  - Export: n, k vs wavelength
  
- **Alternative**: Use template provided
  - File: `material_properties/silicon_optical.dat`
  - Covers 0.3-1.2 μm range

**Format**: Space-separated (wavelength, n, k, α)

---

### 4. Trained ML Models
**Location**: `data/trained_models/`

**How to generate**:
1. Run SimV1-SimV3 to generate training data:
   ```bash
   ./bin/aura_mf --mode simv1 --grid 50x50x5 --output train_hf.dat
   ./bin/aura_mf --mode simv2 --grid 25x25x5 --output train_lf.dat
   ```

2. Train Random Forest:
   ```bash
   python3 python/ml_training/ml_trainer.py \
       --data training_data.npy \
       --output data/trained_models/rf_orchestrator.bin
   ```

3. Resulting files:
   - `rf_orchestrator.bin` (Fortran binary)
   - `rf_orchestrator.pkl` (Python pickle)

**Format**: Binary (Fortran-readable) + Pickle (Python)

---

## Quick Start with Templates

If you want to run AURA-MF immediately with placeholder data:

```bash
# Use provided templates
cd AURA_MF/data

# Templates are already in place:
# - sandia_validation/pvmc_template.csv
# - atmospheric_luts/am15_global.csv
# - material_properties/silicon_optical.dat

# These allow basic testing but should be replaced with
# full datasets for production validation
```

---

## Production Data Checklist

- [ ] Sandia PVMC or NREL PVDAQ dataset (1 year minimum)
- [ ] ASTM G173-03 reference spectra (full wavelength range)
- [ ] Silicon optical properties (Green & Keevers or PVLighthouse)
- [ ] Trained Random Forest model (200+ trees)
- [ ] Training data (100+ simulations across fidelities)

---

## Data Quality Requirements

**Sandia PVMC**:
- Temporal resolution: ≤ 1 hour
- Missing data: < 5%
- Operating conditions: 800-1200 W/m², 15-45°C ambient
- Wind speed: 0-10 m/s

**Spectral Data**:
- Wavelength range: 0.3-1.2 μm minimum
- Resolution: ≤ 10 nm
- Accuracy: ± 5%

**ML Training**:
- Minimum samples: 100 (LF), 50 (MF), 20 (HF)
- Feature coverage: Full operating envelope
- Validation split: 20%

---

## Contact for Data Issues

- NREL Support: https://www.nrel.gov/contact/
- Sandia PVMC: pvpmc@sandia.gov
- AURA-MF Issues: [Your GitHub repo]
