# AURA-MF Missing Data Package

## Overview

This package contains **TEMPLATE DATA FILES** that are missing from the base AURA-MF V2.0 distribution. These templates allow you to test the framework immediately, but **should be replaced with production-quality data** for validation and real-world use.

## Contents

```
MISSING_DATA/
├── atmospheric_luts/
│   └── am15_global.csv                    # AM1.5 Global solar spectrum template
├── material_properties/
│   └── silicon_optical.dat                # Silicon optical properties template
├── sandia_validation/
│   └── pvmc_validation_template.csv       # PVMC validation dataset template
└── trained_models/
    └── README_GENERATE_MODELS.md          # Instructions for model generation
```

## Installation

Extract this package into your AURA-MF data directory:

```bash
# Option 1: Extract and merge
unzip AURA_MF_MISSING_DATA.zip
cp -r MISSING_DATA/* /path/to/AURA_MF_V2.0/data/

# Option 2: Direct extraction
cd /path/to/AURA_MF_V2.0/data/
unzip /path/to/AURA_MF_MISSING_DATA.zip
mv MISSING_DATA/* .
rmdir MISSING_DATA
```

## File Details

### 1. Atmospheric Spectral Irradiance (am15_global.csv)

**Purpose**: Solar spectrum for photovoltaic calculations  
**Template**: 100 wavelength points (0.3-1.2 μm)  
**Production**: Download full ASTM G173-03 dataset

**How to get production data**:
```bash
# Visit NREL and download ASTM G173-03
wget https://www.nrel.gov/grid/solar-resource/assets/data/astmg173.csv
# Or use SMARTS model for location-specific spectra
# https://www.nrel.gov/grid/solar-resource/smarts.html
```

**Template limitations**:
- Only 100 wavelength points (production has ~2000)
- Fixed air mass 1.5 (no angle dependence)
- Average atmospheric conditions

### 2. Silicon Optical Properties (silicon_optical.dat)

**Purpose**: Refractive index and absorption for silicon PV cells  
**Template**: 50 wavelength points (0.3-1.2 μm)  
**Production**: Use Green & Keevers (1995) full dataset

**How to get production data**:
```bash
# Option 1: Download from PVLighthouse
# Visit: https://www.pvlighthouse.com.au/refractive-index
# Select: Silicon (crystalline)
# Export: n, k, α vs wavelength

# Option 2: Use published data
# Green, M. A., & Keevers, M. J. (1995)
# "Optical properties of intrinsic silicon at 300 K"
# Progress in Photovoltaics, 3(3), 189-192
```

**Template limitations**:
- Interpolated data (not measured)
- 300K only (no temperature dependence)
- Crystalline silicon only (no amorphous/multicrystalline)

### 3. Sandia PVMC Validation Data (pvmc_validation_template.csv)

**Purpose**: Real-world module temperature measurements for validation  
**Template**: 24 hours of synthetic data  
**Production**: Download 1+ year of measured data

**How to get production data**:
```bash
# Option 1: Sandia PVMC Database
# Visit: https://pvpmc.sandia.gov/
# Navigate: Data Sets → Module Temperature
# Download: CSV with timestamp, T_module, G_poa, T_ambient, wind_speed

# Option 2: NREL PVDAQ
# Visit: https://maps.nrel.gov/pvdaq/
# Select: Site with module temperature sensors
# Export: Hourly data for 1+ year
```

**Template limitations**:
- Only 24 hours (need 8,760+ for full validation)
- Synthetic data (not measured)
- Single module type
- Idealized conditions (no clouds, soiling, degradation)

### 4. Trained ML Models (rf_orchestrator.bin/pkl)

**Purpose**: Random Forest models for ML-accelerated multifidelity simulations  
**Template**: NONE - must be generated  
**Production**: Train on your simulation data

**How to generate**:

See `trained_models/README_GENERATE_MODELS.md` for complete instructions.

Quick start:
```bash
# 1. Generate training data
./aura_mf --mode simv1 --samples 100 --output train_lf.dat
./aura_mf --mode simv2 --samples 50 --output train_mf.dat
./aura_mf --mode simv3 --samples 20 --output train_hf.dat

# 2. Train model
python3 python/ml_training/ml_trainer.py \
    --data train_*.dat \
    --output data/trained_models/rf_orchestrator

# 3. Validate
./aura_mf --mode simv4 --validate
```

**Why models can't be pre-generated**:
- System-specific (compiler, architecture, libraries)
- Training data depends on your use case
- Model performance degrades if not trained on relevant conditions

## Data Quality Requirements

### For Testing (Templates Sufficient)
- ✅ Running the code without errors
- ✅ Understanding the framework
- ✅ Development and debugging
- ✅ Unit tests

### For Validation (Production Data Required)
- ❌ Publishing results
- ❌ Real-world predictions
- ❌ Performance benchmarking
- ❌ Scientific validation

## Production Data Checklist

Before using AURA-MF for production work, replace ALL templates:

- [ ] **Atmospheric spectra**: Full ASTM G173-03 or SMARTS-generated
- [ ] **Silicon optical**: Full Green & Keevers or PVLighthouse data
- [ ] **Validation data**: 1+ year of measured PVMC or PVDAQ data
- [ ] **ML models**: Trained on 100+ samples across all fidelity levels

## Validation Metrics

To ensure data quality:

```bash
# Check atmospheric spectrum total irradiance
python3 python/validate_data.py --spectrum data/atmospheric_luts/am15_global.csv
# Expected: 1000 ± 10 W/m² integrated irradiance

# Verify silicon optical properties
python3 python/validate_data.py --optical data/material_properties/silicon_optical.dat
# Expected: Consistent with published literature at 300K

# Validate PVMC dataset
python3 python/validate_data.py --pvmc data/sandia_validation/pvmc_*.csv
# Expected: < 5% missing data, realistic T_module vs G_poa correlation
```

## Support

**Data acquisition issues**:
- NREL Support: https://www.nrel.gov/contact/
- Sandia PVMC: pvpmc@sandia.gov

**AURA-MF specific**:
- Check DATA_ACQUISITION_GUIDE.md in the main data/ directory
- Review documentation in docs/

## License Notes

**Template data in this package**:
- AM1.5 spectrum: Based on ASTM G173-03 (public domain)
- Silicon optical: Based on Green & Keevers (1995) published values
- PVMC template: Synthetic data (not measured)

**When using production data**, ensure compliance with:
- NREL data use terms
- Sandia data sharing agreements  
- Published literature citation requirements

## Changelog

**Version 1.0** (2026-02-02)
- Initial release
- AM1.5 global spectrum template (100 wavelengths)
- Silicon optical properties template (50 wavelengths)
- PVMC validation template (24 hours)
- ML model generation instructions

---

**REMEMBER**: Templates are for TESTING only. Replace with production data for real work!
