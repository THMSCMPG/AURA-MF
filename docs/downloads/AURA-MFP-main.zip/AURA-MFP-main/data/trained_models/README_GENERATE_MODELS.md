# Trained Models Directory

## IMPORTANT: Model files must be generated

This directory should contain trained Random Forest models for the ML-accelerated multifidelity framework. **These files cannot be pre-generated** and must be created by running the AURA-MF training workflow.

## Required Files

1. **rf_orchestrator.bin** - Fortran-readable binary format
2. **rf_orchestrator.pkl** - Python pickle format

## How to Generate

### Step 1: Generate Training Data

Run simulations at multiple fidelity levels to create training dataset:

```bash
# High-fidelity training data (expensive, fewer samples)
./aura_mf --mode simv3 --grid 50x50x5 --samples 20 --output train_hf.dat

# Medium-fidelity training data (moderate cost/accuracy)
./aura_mf --mode simv2 --grid 25x25x5 --samples 50 --output train_mf.dat

# Low-fidelity training data (cheap, many samples)
./aura_mf --mode simv1 --grid 10x10x3 --samples 100 --output train_lf.dat
```

### Step 2: Combine and Preprocess

```bash
python3 python/data_acquisition.py \
    --combine train_hf.dat train_mf.dat train_lf.dat \
    --output training_data.npy
```

### Step 3: Train Random Forest Model

```bash
python3 python/ml_training/ml_trainer.py \
    --data training_data.npy \
    --n_estimators 200 \
    --max_depth 15 \
    --output data/trained_models/rf_orchestrator
```

This will generate both `.bin` and `.pkl` files.

### Step 4: Validate Model

```bash
./aura_mf --mode simv4 --validate --model data/trained_models/rf_orchestrator.bin
```

## Model Specifications

- **Algorithm**: Random Forest Regressor
- **Input Features**: 
  - Temperature (module, ambient, cell)
  - Irradiance (POA, direct, diffuse)
  - Wind speed
  - Optical properties
  - Thermal properties
  
- **Output Predictions**:
  - Temperature distribution
  - Heat flux
  - Optical losses
  - Performance metrics

- **Training Requirements**:
  - Minimum samples: 100 (LF), 50 (MF), 20 (HF)
  - Validation split: 20%
  - Cross-validation: 5-fold

## Placeholder Files

If you need to test AURA-MF before generating real models, you can use:

```bash
# Create dummy model files (NOT for production use)
python3 python/create_dummy_models.py
```

**WARNING**: Dummy models will not provide accurate predictions and are only for testing the simulation framework.

## Model Performance Targets

- **R² score**: > 0.95 on validation set
- **Mean Absolute Error**: < 2°C for temperature predictions
- **Speedup**: 100-1000x vs high-fidelity simulation
- **Memory**: < 500 MB for binary file

## Troubleshooting

**Error: "Cannot load model file"**
- Ensure model was trained with same AURA-MF version
- Check file permissions
- Verify binary compatibility (Fortran compiler version)

**Error: "Model predictions out of range"**
- Training data may not cover operating envelope
- Increase training samples
- Check for data preprocessing errors

**Low model accuracy**
- Increase number of trees (n_estimators)
- Adjust max_depth
- Add more training data from underrepresented regions
- Check for label/feature mismatch

## References

- Breiman, L. (2001). Random Forests. Machine Learning, 45(1), 5-32.
- Peherstorfer, B., et al. (2018). Survey of multifidelity methods in uncertainty quantification, inference, and optimization. SIAM Review, 60(3), 550-591.
