#!/bin/bash

set -e

# Build AURA-MF with CMake
mkdir -p build
cd build

cmake .. \
    -DCMAKE_INSTALL_PREFIX=$PREFIX \
    -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_Fortran_COMPILER=$FC \
    -DCMAKE_C_COMPILER=$CC

cmake --build . -j${CPU_COUNT}

# Install executable
install -d $PREFIX/bin
install -m 755 aura_mf $PREFIX/bin/aura_mf_v3

# Install Python package
cd ../python
$PYTHON -m pip install . -vv --no-deps

# Create data directory
install -d $PREFIX/share/aura-mf
cp -r ../data/* $PREFIX/share/aura-mf/
