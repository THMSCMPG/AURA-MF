#!/bin/bash
# AURA-MF Automated Installation Script
# Supports: Ubuntu, macOS, WSL2

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
REPO_URL="https://github.com/yourusername/aura-mf.git"
INSTALL_DIR="$HOME/aura-mf"
VENV_DIR="$INSTALL_DIR/venv"

# Functions
print_header() {
    echo -e "\n${BLUE}========================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}========================================${NC}\n"
}

print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

print_error() {
    echo -e "${RED}✗ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠ $1${NC}"
}

# Detect OS
detect_os() {
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        if grep -q Microsoft /proc/version; then
            OS="wsl"
        else
            OS="linux"
        fi
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        OS="macos"
    else
        print_error "Unsupported OS: $OSTYPE"
        exit 1
    fi
    print_success "Detected OS: $OS"
}

# Check dependencies
check_dependencies() {
    print_header "Checking Dependencies"
    
    local missing=0
    
    # Check gfortran
    if command -v gfortran &> /dev/null; then
        GFORTRAN_VERSION=$(gfortran --version | head -n1)
        print_success "gfortran found: $GFORTRAN_VERSION"
    else
        print_warning "gfortran not found"
        missing=1
    fi
    
    # Check gcc
    if command -v gcc &> /dev/null; then
        GCC_VERSION=$(gcc --version | head -n1)
        print_success "gcc found: $GCC_VERSION"
    else
        print_warning "gcc not found"
        missing=1
    fi
    
    # Check python3
    if command -v python3 &> /dev/null; then
        PYTHON_VERSION=$(python3 --version)
        print_success "python3 found: $PYTHON_VERSION"
    else
        print_warning "python3 not found"
        missing=1
    fi
    
    # Check make
    if command -v make &> /dev/null; then
        print_success "make found"
    else
        print_warning "make not found"
        missing=1
    fi
    
    return $missing
}

# Install dependencies
install_dependencies() {
    print_header "Installing Dependencies"
    
    case $OS in
        linux|wsl)
            print_success "Installing via apt-get..."
            sudo apt-get update
            sudo apt-get install -y \
                gfortran \
                gcc \
                g++ \
                cmake \
                make \
                libgomp1 \
                python3 \
                python3-pip \
                python3-venv \
                git
            ;;
        macos)
            # Check if Homebrew is installed
            if ! command -v brew &> /dev/null; then
                print_warning "Homebrew not found. Installing..."
                /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
            fi
            
            print_success "Installing via Homebrew..."
            brew install gcc cmake python git
            ;;
    esac
    
    print_success "Dependencies installed"
}

# Clone repository
clone_repo() {
    print_header "Cloning AURA-MF Repository"
    
    if [ -d "$INSTALL_DIR" ]; then
        print_warning "Directory $INSTALL_DIR already exists"
        read -p "Remove and re-clone? (y/n) " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            rm -rf "$INSTALL_DIR"
        else
            print_error "Installation cancelled"
            exit 1
        fi
    fi
    
    git clone "$REPO_URL" "$INSTALL_DIR"
    cd "$INSTALL_DIR"
    print_success "Repository cloned to $INSTALL_DIR"
}

# Setup Python virtual environment
setup_python() {
    print_header "Setting up Python Environment"
    
    # Create virtual environment
    python3 -m venv "$VENV_DIR"
    source "$VENV_DIR/bin/activate"
    
    # Upgrade pip
    pip install --upgrade pip
    
    # Install requirements
    if [ -f "python/requirements.txt" ]; then
        pip install -r python/requirements.txt
        print_success "Python dependencies installed"
    else
        print_warning "requirements.txt not found"
    fi
}

# Build AURA-MF
build_aura() {
    print_header "Building AURA-MF"
    
    cd "$INSTALL_DIR"
    
    # Set compiler for macOS
    if [ "$OS" == "macos" ]; then
        export FC=gfortran-12
        export CC=gcc-12
    fi
    
    # Clean and build
    make clean
    make -j$(nproc 2>/dev/null || sysctl -n hw.ncpu 2>/dev/null || echo 4)
    
    if [ -f "aura_mf_v3" ]; then
        print_success "Build completed successfully"
    else
        print_error "Build failed - executable not found"
        exit 1
    fi
}

# Run tests
run_tests() {
    print_header "Running Tests"
    
    cd "$INSTALL_DIR"
    
    # Quick executable test
    if ./aura_mf_v3 --help &> /dev/null || true; then
        print_success "Executable test passed"
    else
        print_warning "Executable test failed or timed out"
    fi
    
    # Python tests (if pytest available)
    if command -v pytest &> /dev/null; then
        cd python
        pytest tests/ -v --maxfail=3 || print_warning "Some Python tests failed"
        cd ..
    else
        print_warning "pytest not available, skipping Python tests"
    fi
}

# Setup PATH
setup_path() {
    print_header "Setting up PATH"
    
    local shell_rc=""
    if [ -n "$BASH_VERSION" ]; then
        shell_rc="$HOME/.bashrc"
    elif [ -n "$ZSH_VERSION" ]; then
        shell_rc="$HOME/.zshrc"
    fi
    
    if [ -n "$shell_rc" ]; then
        # Add to PATH
        echo "" >> "$shell_rc"
        echo "# AURA-MF" >> "$shell_rc"
        echo "export PATH=\"$INSTALL_DIR:\$PATH\"" >> "$shell_rc"
        echo "export AURA_MF_HOME=\"$INSTALL_DIR\"" >> "$shell_rc"
        
        # Add virtual environment activation
        echo "# Activate AURA-MF Python environment (optional)" >> "$shell_rc"
        echo "# source \"$VENV_DIR/bin/activate\"" >> "$shell_rc"
        
        print_success "Added to $shell_rc"
        print_warning "Run: source $shell_rc"
    fi
}

# Main installation
main() {
    print_header "AURA-MF Installation Script"
    echo "This script will install AURA-MF and its dependencies."
    echo ""
    
    # Detect OS
    detect_os
    
    # Check dependencies
    if ! check_dependencies; then
        read -p "Install missing dependencies? (y/n) " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            install_dependencies
        else
            print_error "Cannot proceed without dependencies"
            exit 1
        fi
    fi
    
    # Clone repository
    clone_repo
    
    # Setup Python
    setup_python
    
    # Build
    build_aura
    
    # Run tests
    read -p "Run tests? (y/n) " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        run_tests
    fi
    
    # Setup PATH
    setup_path
    
    # Success message
    print_header "Installation Complete!"
    echo -e "${GREEN}AURA-MF has been successfully installed to: $INSTALL_DIR${NC}"
    echo ""
    echo "To get started:"
    echo "  1. source ~/.bashrc  (or restart terminal)"
    echo "  2. cd $INSTALL_DIR"
    echo "  3. ./aura_mf_v3 --help"
    echo ""
    echo "For tutorials and documentation, see:"
    echo "  $INSTALL_DIR/docs/"
    echo ""
    echo -e "${BLUE}Happy simulating!${NC}"
}

# Run main
main
