# AURA-MFP
### Atmosphere-Unified Radiation Assessment with Multi-Fidelity for Photovoltaics

**AURA-MFP** is a high-performance framework designed to model atmospheric radiation with a focus on photovoltaic (PV) efficiency. By leveraging a proprietary multi-fidelity architecture, it bridges the gap between fast, low-fidelity estimations and computationally intensive, high-fidelity physics simulations.

> [!IMPORTANT]
> **Current Status: Beta Production.** > This software is undergoing active development as part of an undergraduate capstone project. APIs are subject to change, and features may be incomplete.

---

## 🔬 Technical Core

The framework is built upon a physical backbone to ensure high-accuracy radiation modeling:

* **Atmospheric-Unified Engine:** Utilizes **Boltzmann Transport Equations** coupled with **Navier-Stokes Equations** to simulate fluid dynamics and particle transport within the atmosphere.
* **PV-Centric Output:** Provides direct calculation of spectral irradiance and projected PV power output.

### Multi-Fidelity Optimization
AURA-MFP utilizes a four-tier simulation strategy to maximize computational efficiency without sacrificing physical integrity:

| Tier | Name | Description |
| :--- | :--- | :--- |
| **Sim1** | Rigorous | Full physical simulation (High-Fidelity) |
| **Sim2** | Empirical | Fast, data-driven estimations (Low-Fidelity & High-Fidelity) |
| **Sim3** | Goldilocks | Optimized balanced-fidelity modeling (Low-Medium-High Fidelity) |
| **Sim4** | ML Orchestrator | Machine Learning layer for intelligent model selection |

---

## 🛠 Usage & Contributions

### Contributions
**Notice:** This repository is currently associated with active undergraduate capstone research. To maintain the integrity of the academic assessment and upcoming publications, **outside contributions and Pull Requests are discouraged until after 2028.**

### License & Attribution
This software is provided for **non-commercial use only**, including but not limited to:
* Academic research
* Personal hobbyist projects
* Educational demonstrations

**Requirements for Use:**
Any published work, software, or research papers that utilize AURA-MFP must provide formal citation to:
1.  The lead author (William T. Campagna).
2.  Any published research papers associated with AURA-MFP.
3.  This GitHub repository.

APA

Campagna, W. (2026). AURA-MFP: Atmosphere-Unified Radiation Assessment with Multi-Fidelity for Photovoltaics (Version #-beta). https://github.com/THMSCMPG/AURA-MFP

BibTeX

Code snippet
@software{AURA_MFP_2026,
  author = {Campagna, William Thomas},
  title = {{AURA-MFP: Atmosphere-Unified Radiation Assessment with Multi-Fidelity for Photovoltaics}},
  url = {https://github.com/THMSCMPG/AURA-MFP},
  version = {0.1.0-beta},
  year = {2026},
  note = {Currently in Beta Production - Undergraduate Capstone Project}
}

---

## 📅 Project Timeline
* **2025–2026:** Development and Beta Testing (Capstone Phase).
* **2027:** Peer-reviewed publication, validation, and presenting Capstone.
