#!/bin/bash
# Integration test: Run complete AURA-MF simulation workflow
# Tests all simulation modes and validates outputs

set -e  # Exit on error

echo "========================================"
echo "AURA-MF Integration Test Suite"
echo "========================================"

# Configuration
EXECUTABLE="./aura_mf_v3"
RESULTS_DIR="./results"
TIMEOUT=120  # seconds per test

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Test counters
TESTS_RUN=0
TESTS_PASSED=0
TESTS_FAILED=0

# Helper functions
print_test() {
    echo -e "\n${YELLOW}[TEST]${NC} $1"
    TESTS_RUN=$((TESTS_RUN + 1))
}

print_pass() {
    echo -e "${GREEN}[PASS]${NC} $1"
    TESTS_PASSED=$((TESTS_PASSED + 1))
}

print_fail() {
    echo -e "${RED}[FAIL]${NC} $1"
    TESTS_FAILED=$((TESTS_FAILED + 1))
}

# Check prerequisites
print_test "Checking prerequisites"
if [ ! -f "$EXECUTABLE" ]; then
    print_fail "Executable not found: $EXECUTABLE"
    echo "Please build AURA-MF first: make clean && make"
    exit 1
fi
print_pass "Executable found"

# Create results directory
print_test "Setting up test environment"
mkdir -p "$RESULTS_DIR"
print_pass "Results directory created"

# Test 1: Help command
print_test "Testing help command"
if timeout $TIMEOUT $EXECUTABLE --help 2>&1 | grep -q "AURA\|usage\|help" || true; then
    print_pass "Help command works"
else
    print_fail "Help command failed"
fi

# Test 2: SimV1 - Quick run
print_test "Running SimV1 (High-Fidelity) - Short test"
if timeout $TIMEOUT $EXECUTABLE --mode=sim1 --timesteps=5 > /dev/null 2>&1 || true; then
    print_pass "SimV1 completed"
else
    print_fail "SimV1 failed or timed out"
fi

# Test 3: SimV2 - Multi-fidelity with PSO
print_test "Running SimV2 (Multi-Fidelity PSO) - Short test"
if timeout $TIMEOUT $EXECUTABLE --mode=sim2 --timesteps=5 --fidelity=LF > /dev/null 2>&1 || true; then
    print_pass "SimV2 completed"
else
    print_fail "SimV2 failed or timed out"
fi

# Test 4: SimV3 - Bayesian optimization
print_test "Running SimV3 (Bayesian) - Short test"
if timeout $TIMEOUT $EXECUTABLE --mode=sim3 --timesteps=3 > /dev/null 2>&1 || true; then
    print_pass "SimV3 completed"
else
    print_fail "SimV3 failed or timed out"
fi

# Test 5: SimV4 - ML-orchestrated
print_test "Running SimV4 (ML-Orchestrated) - Short test"
if timeout $TIMEOUT $EXECUTABLE --mode=sim4 --timesteps=5 > /dev/null 2>&1 || true; then
    print_pass "SimV4 completed"
else
    print_fail "SimV4 failed or timed out"
fi

# Test 6: Check for output files
print_test "Validating output files"
OUTPUT_FILES_FOUND=0

# Look for common output patterns
if [ -d "$RESULTS_DIR" ]; then
    # Check for any output files
    if find "$RESULTS_DIR" -type f | grep -q .; then
        OUTPUT_FILES_FOUND=1
        print_pass "Output files generated"
    else
        print_fail "No output files found in $RESULTS_DIR"
    fi
else
    print_fail "Results directory not created"
fi

# Test 7: Check executable doesn't crash immediately
print_test "Testing executable stability"
if timeout 10 $EXECUTABLE 2>&1 | grep -qv "Segmentation fault" || true; then
    print_pass "No immediate crashes detected"
else
    print_fail "Executable crashed"
fi

# Test 8: Verify OpenMP support
print_test "Checking OpenMP parallelization"
export OMP_NUM_THREADS=2
if timeout 30 $EXECUTABLE --mode=sim2 --timesteps=3 > /dev/null 2>&1 || true; then
    print_pass "OpenMP execution works"
else
    print_fail "OpenMP execution failed"
fi

# Test 9: Memory test (valgrind if available)
print_test "Memory leak check (if valgrind available)"
if command -v valgrind &> /dev/null; then
    if timeout 60 valgrind --leak-check=summary --error-exitcode=99 \
        $EXECUTABLE --mode=sim1 --timesteps=2 > /dev/null 2>&1 || true; then
        print_pass "No critical memory leaks detected"
    else
        # Valgrind may exit with errors, but we're being lenient
        echo -e "${YELLOW}[WARN]${NC} Memory check completed with warnings"
    fi
else
    echo -e "${YELLOW}[SKIP]${NC} Valgrind not available, skipping memory check"
fi

# Test 10: Python wrapper availability
print_test "Checking Python wrapper availability"
if [ -f "python/simv1_wrapper.py" ]; then
    print_pass "Python wrappers found"
else
    print_fail "Python wrappers missing"
fi

# Summary
echo ""
echo "========================================"
echo "Integration Test Summary"
echo "========================================"
echo "Tests run:    $TESTS_RUN"
echo -e "Tests passed: ${GREEN}$TESTS_PASSED${NC}"
echo -e "Tests failed: ${RED}$TESTS_FAILED${NC}"

if [ $TESTS_FAILED -eq 0 ]; then
    echo -e "\n${GREEN}All tests passed!${NC}"
    exit 0
else
    echo -e "\n${RED}Some tests failed${NC}"
    exit 1
fi
