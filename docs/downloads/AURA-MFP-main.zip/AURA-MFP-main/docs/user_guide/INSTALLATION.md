# AURA-MF Installation Guide

Complete installation instructions for AURA-MF Multi-Fidelity Photovoltaic Simulation Framework.

## Table of Contents

- [Quick Start](#quick-start)
- [System Requirements](#system-requirements)
- [Installation Methods](#installation-methods)
  - [Docker (Recommended)](#docker-recommended)
  - [Conda](#conda)
  - [From Source](#from-source)
- [Platform-Specific Instructions](#platform-specific-instructions)
- [Verification](#verification)
- [Troubleshooting](#troubleshooting)

---

## Quick Start

### Using Docker (Easiest)

```bash
# Pull and run
docker pull aura-mf:beta
docker run -it aura-mf:beta

# Or build from source
git clone https://github.com/yourusername/aura-mf.git
cd aura-mf
docker build -t aura-mf:beta .
docker run -it aura-mf:beta
```

### Using Installation Script

```bash
# Download and run installer
curl -sSL https://raw.githubusercontent.com/yourusername/aura-mf/main/install.sh | bash

# Or clone and install
git clone https://github.com/yourusername/aura-mf.git
cd aura-mf
./install.sh
```

---

## System Requirements

### Minimum Requirements

- **CPU**: 2 cores (4+ recommended)
- **RAM**: 4 GB (8+ GB recommended)
- **Disk**: 2 GB free space
- **OS**: Linux (Ubuntu 20.04+), macOS (10.15+), Windows (WSL2)

### Software Dependencies

#### Required
- Fortran compiler (gfortran 9.0+ or ifort 19.0+)
- C compiler (gcc 9.0+)
- OpenMP support
- Python 3.8+
- CMake 3.15+ (optional, for CMake build)
- Make

#### Optional
- MPI (for future multi-node support)
- HDF5 (for advanced data output)
- CUDA (for GPU acceleration - future)

---

## Installation Methods

### Docker (Recommended)

Docker provides the most consistent experience across platforms.

#### Prerequisites
- Docker Desktop (Windows/macOS) or Docker Engine (Linux)
- 4 GB RAM allocated to Docker

#### Steps

1. **Pull pre-built image** (when available):
```bash
docker pull ghcr.io/yourusername/aura-mf:beta
```

2. **Or build from source**:
```bash
git clone https://github.com/yourusername/aura-mf.git
cd aura-mf
docker build -t aura-mf:beta .
```

3. **Run container**:
```bash
# Interactive session
docker run -it --rm -v $(pwd)/results:/app/results aura-mf:beta

# Specific simulation
docker run --rm -v $(pwd)/results:/app/results aura-mf:beta \
    /app/aura_mf_v3 --mode=sim1 --timesteps=100
```

4. **With Docker Compose** (development):
```bash
docker-compose up -d
docker-compose exec aura-dev bash
```

---

### Conda

Conda provides isolated Python and system dependencies.

#### Prerequisites
- Anaconda or Miniconda installed

#### Steps

1. **Create conda environment**:
```bash
conda create -n aura-mf python=3.10 -y
conda activate aura-mf
```

2. **Install system dependencies**:
```bash
# Linux
conda install -c conda-forge gfortran gcc cmake make -y

# macOS
conda install -c conda-forge gfortran_osx-64 clang cmake make -y
```

3. **Install AURA-MF**:
```bash
# From conda package (when available)
conda install -c yourusername aura-mf

# Or from source
git clone https://github.com/yourusername/aura-mf.git
cd aura-mf
pip install -r python/requirements.txt
make clean && make
```

---

### From Source

Build directly on your system.

#### Ubuntu/Debian

```bash
# 1. Install dependencies
sudo apt-get update
sudo apt-get install -y \
    gfortran \
    gcc \
    g++ \
    cmake \
    make \
    libgomp1 \
    python3 \
    python3-pip \
    git

# 2. Clone repository
git clone https://github.com/yourusername/aura-mf.git
cd aura-mf

# 3. Install Python dependencies
pip3 install -r python/requirements.txt

# 4. Build
make clean
make -j$(nproc)

# 5. Test
./aura_mf_v3 --help
```

#### macOS

```bash
# 1. Install Homebrew (if not installed)
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# 2. Install dependencies
brew install gcc cmake python

# 3. Clone repository
git clone https://github.com/yourusername/aura-mf.git
cd aura-mf

# 4. Set compiler
export FC=gfortran-12
export CC=gcc-12

# 5. Install Python dependencies
pip3 install -r python/requirements.txt

# 6. Build
make clean
make -j$(sysctl -n hw.ncpu)

# 7. Test
./aura_mf_v3 --help
```

#### Windows (WSL2)

```bash
# 1. Enable WSL2
# Follow: https://docs.microsoft.com/en-us/windows/wsl/install

# 2. Install Ubuntu from Microsoft Store

# 3. In WSL terminal, follow Ubuntu instructions above
sudo apt-get update
sudo apt-get install -y gfortran gcc cmake make python3 python3-pip git

git clone https://github.com/yourusername/aura-mf.git
cd aura-mf
pip3 install -r python/requirements.txt
make clean && make -j$(nproc)
```

---

## Platform-Specific Instructions

### HPC Clusters

For use on high-performance computing clusters:

```bash
# 1. Load modules (example for SLURM)
module load gcc/11.2.0
module load cmake/3.22
module load python/3.10

# 2. Clone and build
git clone https://github.com/yourusername/aura-mf.git
cd aura-mf

# 3. Build with MPI support (future)
# CC=mpicc FC=mpif90 cmake . -DUSE_MPI=ON
# make -j16

# 4. Current build
make clean
make -j16
```

### ARM Architecture (Apple Silicon)

```bash
# Use native ARM compiler
export FC=/opt/homebrew/bin/gfortran
export CC=/opt/homebrew/bin/gcc

# Build
make clean
make FFLAGS="-O3 -mcpu=apple-m1 -fopenmp"
```

---

## Verification

After installation, verify AURA-MF works correctly:

### 1. Check Executable

```bash
./aura_mf_v3 --help
# Should display help message
```

### 2. Run Quick Test

```bash
./aura_mf_v3 --mode=sim1 --timesteps=5
# Should complete without errors
```

### 3. Run Test Suite

```bash
# Integration tests
chmod +x tests/integration/test_full_simulation.sh
./tests/integration/test_full_simulation.sh

# Python tests
cd python
pytest tests/ -v
```

### 4. Check OpenMP

```bash
export OMP_NUM_THREADS=4
./aura_mf_v3 --mode=sim2 --timesteps=10
# Should utilize 4 threads
```

---

## Troubleshooting

### Common Issues

#### 1. "gfortran: command not found"

**Solution**: Install gfortran
```bash
# Ubuntu/Debian
sudo apt-get install gfortran

# macOS
brew install gcc

# Conda
conda install -c conda-forge gfortran
```

#### 2. "cannot find -lgomp"

**Problem**: OpenMP library missing

**Solution**:
```bash
# Ubuntu/Debian
sudo apt-get install libgomp1

# macOS (already included with gcc from Homebrew)

# Conda
conda install -c conda-forge libgomp
```

#### 3. "Module dependency errors" during compilation

**Problem**: Incorrect module compilation order

**Solution**:
```bash
make clean
make  # Makefile has correct order
```

#### 4. Segmentation fault at runtime

**Possible causes**:
- Stack size too small
- Array bounds violation

**Solutions**:
```bash
# Increase stack size
ulimit -s unlimited

# Rebuild with bounds checking
make clean
make debug
./aura_mf_v3
```

#### 5. Python import errors

**Problem**: Python dependencies not installed

**Solution**:
```bash
pip3 install -r python/requirements.txt
```

#### 6. Permission denied

**Problem**: Executable not marked as executable

**Solution**:
```bash
chmod +x aura_mf_v3
```

### Getting Help

If you encounter issues not covered here:

1. **Check Issues**: Search [GitHub Issues](https://github.com/yourusername/aura-mf/issues)
2. **Documentation**: Read the [User Guide](user_guide/README.md)
3. **Create Issue**: Open a new issue with:
   - OS and version
   - Compiler version (`gfortran --version`)
   - Complete error message
   - Steps to reproduce

---

## Uninstallation

### Docker
```bash
docker rmi aura-mf:beta
```

### Conda
```bash
conda remove --name aura-mf --all
```

### From Source
```bash
cd aura-mf
make clean
cd ..
rm -rf aura-mf
```

---

**Version**: 1.0-beta  
**Last Updated**: February 2026  
**Feedback**: Open an issue or submit a PR
