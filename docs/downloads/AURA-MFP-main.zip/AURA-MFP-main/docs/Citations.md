# Citations

---

## Sandia National Laboratories Citations

### 1. General Institutional Citation
* **Sandia National Laboratories.** (n.d.). *Sandia National Laboratories*. [https://www.sandia.gov/](https://www.sandia.gov/)

### 2. PV Performance Modeling Collaborative (PVPMC) Datasets
* **Sandia National Laboratories.** (2026). *Photovoltaic Performance Modeling Collaborative (PVPMC) Datasets*. [https://pvpmc.sandia.gov/datasets/](https://pvpmc.sandia.gov/datasets/)

---

## Research Papers 

### 1. PV Thermal Modeling & Sandia Benchmarking
- **King, D. L., et al. (2004).** "Photovoltaic Module Operating Temperature Model." _Sandia National Laboratories Report_.
    - **Direct Link/ID:** [DOI: 10.2172/919131](https://doi.org/10.2172/919131)
- **Faiman, D. (2008).** "Assessing the outdoor operating temperature of photovoltaic modules." _Progress in Photovoltaics_.
    - **Direct Link/ID:** [DOI: 10.1002/pip.813](https://doi.org/10.1002/pip.813)

### 2. Monte Carlo Photon Transport & BTE
- **Howell, J. R. (1998).** "The Monte Carlo Method in Radiative Heat Transfer." _Journal of Heat Transfer_.
    - **Direct Link/ID:** [DOI: 10.1115/1.2825912](https://www.google.com/search?q=https://doi.org/10.1115/1.2825912)
- **Modest, M. F. (2003).** "Radiative Heat Transfer." (Specifically Chapter 20: The Monte Carlo Method).
    - **Direct Link/ID:** [ISBN: 978-0125031639](https://www.google.com/search?q=ISBN+978-0125031639)

### 3. Multi-Fidelity Modeling & Co-Kriging
- **Kennedy, M. C., & O'Hagan, A. (2000).** "Predicting the output from a complex computer code when fast approximations are available." _Biometrika_.
    - **Direct Link/ID:** [DOI: 10.1093/biomet/87.1.1](https://doi.org/10.1093/biomet/87.1.1)
- **Peherstorfer, B., et al. (2018).** "Survey of Multifidelity Methods in Monte Carlo Sampling." _SIAM Review_.
    - **Direct Link/ID:** [arXiv: 1607.03180](https://arxiv.org/abs/1607.03180)

### 4. Adjoint Methods & Optimization
- **Giles, M. B., & Pierce, N. A. (2000).** "An Introduction to the Adjoint Approach to Design." _Flow, Turbulence and Combustion_.
    - **Direct Link/ID:** [DOI: 10.1023/A:1011430410075](https://doi.org/10.1023/A:1011430410075)
- **Kennedy, J., & Eberhart, R. (1995).** "Particle Swarm Optimization." _Proceedings of ICNN'95_.
    - **Direct Link/ID:** [DOI: 10.1109/ICNN.1995.488968](https://doi.org/10.1109/ICNN.1995.488968)

### 5. ML Orchestration & Scientific Machine Learning (SciML)
- **Raissi, M., et al. (2019).** "Physics-informed neural networks: A deep learning framework for solving forward and inverse problems." _Journal of Computational Physics_.
    - **Direct Link/ID:** [arXiv: 1711.10561](https://arxiv.org/abs/1711.10561)
- **Meng, X., & Karniadakis, G. E. (2020).** "A composite neural network that learns from multi-fidelity data." _Journal of Computational Physics_.
    - **Direct Link/ID:** [DOI: 10.1016/j.jcp.2019.109075](https://doi.org/10.1016/j.jcp.2019.109075)

### 6. Atmospheric & Spectral Science
- **Gueymard, C. A. (2004).** "The sun’s total and spectral irradiance for solar energy applications and solar radiation models." _Solar Energy_.
    - **Direct Link/ID:** [DOI: 10.1016/j.solener.2003.08.039](https://www.google.com/search?q=https://doi.org/10.1016/j.solener.2003.08.039)
- **Kasten, F., & Young, A. T. (1989).** "Revised optical air mass tables and approximation formula." _Applied Optics_.
    - **Direct Link/ID:** [DOI: 10.1364/AO.28.004735](https://doi.org/10.1364/AO.28.004735)
